"""Safe server-side diagnostics: does not change network/firewall/database."""
import ipaddress
import json
import os
import re
import socket
import subprocess
import urllib.error
import urllib.request
PORT = 18765
BUILD = 'CO1012-20261106-RETRY-SSE-FIX'
print('======== CAMPUS ONE v0.10.12 SERVER DIAGNOSTIC ========')
print('On SERVER PC, run start_windows.bat first and leave it open.')
print('New port:',PORT, '(old 8765 is NOT used by this build)')
print('\n[1] Loopback /api/health')
try:
    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open('http://127.0.0.1:%s/api/health'%PORT,timeout=4) as r:
        obj=json.load(r)
        print(json.dumps(obj,ensure_ascii=False,indent=2))
        print('Status:', 'CORRECT VERSION' if obj.get('build')==BUILD else 'WRONG SERVER / WRONG VERSION')
except urllib.error.HTTPError as e:
    print('HTTP:',e.code,'- Wrong server / endpoint?')
except Exception as e:
    print('FAILED:',type(e).__name__,str(e))
    print('Server is not listening on localhost:%s. Check launch window.'%PORT)
print('\n[2] Network interfaces (Windows active IPv4 and gateway)')
if os.name=='nt':
    ps='Get-NetIPConfiguration | Where-Object { $_.IPv4Address } | ForEach-Object { "Adapter=" + $_.InterfaceAlias + " IPv4=" + ($_.IPv4Address.IPAddress -join ",") + " Gateway=" + ($_.IPv4DefaultGateway.NextHop -join ",") }'
    try:
        proc=subprocess.run(['powershell','-NoProfile','-Command',ps],capture_output=True,text=True,errors='replace',timeout=12)
        print(proc.stdout.strip() or '(No active IPv4 adapters returned)')
    except Exception as e:print('IPv4 enumeration failed:',e)
    print('\n[3] Network profiles (Private/Public)')
    try:
        cmd=['powershell','-NoProfile','-Command','Get-NetConnectionProfile | Format-Table InterfaceAlias,NetworkCategory,IPv4Connectivity -AutoSize | Out-String -Width 150']
        print(subprocess.run(cmd,capture_output=True,text=True,errors='replace',timeout=12).stdout.strip())
    except Exception as e:print('Network profile query failed:',e)
    print('\n[4] Local TCP port ownership')
    try:
        out=subprocess.run(['netstat','-ano','-p','tcp'],capture_output=True,text=True,encoding='cp949',errors='replace',timeout=9).stdout
        rows=[s.strip() for s in out.splitlines() if re.search(r':%d\s'%PORT,s)]
        print('\n'.join(rows[:20]) if rows else 'No listener on %s'%PORT)
    except Exception as e:print('netstat error:',e)
else:
    print('Windows-only interface and profile info. On Linux/macOS use ipconfig/ifconfig.')
print('\n[5] What to try from OTHER PC')
print('  http://SERVER_IPV4:%d/api/health'%PORT)
print('  http://SERVER_IPV4:%d/'%PORT)
print('  New browser / private window. Do NOT use 127.0.0.1 from other PCs.')
print('  If refused: check LAN IP, server window, firewall, and Wi-Fi AP isolation.')
print('  For Private trusted LAN only: firewall_private_lan_windows.bat as administrator.')
print('======================================================')
