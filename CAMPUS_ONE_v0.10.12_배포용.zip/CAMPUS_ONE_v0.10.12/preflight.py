"""Do not start another server if the diagnostic port is already occupied."""
import socket
import sys
PORT=18765
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
try:
    s.bind(('0.0.0.0',PORT))
except OSError as err:
    print('[ERROR] Port %s cannot be bound: %s' % (PORT,err))
    print('[HINT] A different program is probably using this port, or Windows has reserved it.')
    sys.exit(1)
finally:
    s.close()
print('[OK] Port %s is free.' % PORT)
