"""Voluntary member matching. Separate SQLite DB, no account password/profile changes.

A member explicitly publishes a pseudonymous card and agrees that its content may
be sent to the Gemini service for semantic matching. Schedule constraints are
always checked deterministically before AI ranking.
"""
from __future__ import annotations
import json
import secrets
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path

DAYS = '월화수목금토일'
PERIODS = ('오전', '오후', '저녁')
VALID_SLOTS = frozenset(f'{d}{p}' for d in DAYS for p in PERIODS)
MAX_PUBLIC = 80


class MemberError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def _text(value, maximum, *, required=False):
    if not isinstance(value, str) or len(value)>maximum:
        raise MemberError(f'입력 항목은 {maximum}자 이내의 문자열이어야 합니다.')
    value=value.strip()
    if required and not value:
        raise MemberError('필수 입력 항목을 작성하세요.')
    return value


def clean_slots(value, *, required=False):
    if not isinstance(value, list) or len(value)>21 or any(not isinstance(s,str) or s not in VALID_SLOTS for s in value):
        raise MemberError('가능 시간대는 요일별 오전·오후·저녁 중에서 선택하세요.')
    slots=sorted(set(value),key=lambda s:(DAYS.index(s[0]),PERIODS.index(s[1:])))
    if required and not slots:
        raise MemberError('최소 하나의 활동 가능 시간대를 선택하세요.')
    return slots


def clean_traits(value):
    if not isinstance(value,list) or len(value)>8:
        raise MemberError('성향은 최대 8개까지 등록할 수 있습니다.')
    cleaned=[]
    for v in value:
        v=_text(v,30,required=True)
        if v not in cleaned:cleaned.append(v)
    return cleaned


def clean_profile(data):
    if not isinstance(data,dict):raise MemberError('프로필 형식이 올바르지 않습니다.')
    if data.get('consent_ai') is not True or data.get('published') is not True:
        raise MemberError('학생 프로필 공개와 AI 의미 유사도 분석에 동의해야 등록할 수 있습니다.')
    return {
        'alias':_text(data.get('alias',''),30,required=True),
        'about':_text(data.get('about',''),1000,required=True),
        'role':_text(data.get('role',''),120,required=True),
        'skills':_text(data.get('skills',''),350),
        'traits':clean_traits(data.get('traits',[])),
        'slots':clean_slots(data.get('slots',[]),required=True),
        'consent_ai':True,
    }


def clean_query(data):
    if not isinstance(data,dict):raise MemberError('검색 조건 형식이 올바르지 않습니다.')
    result={
        'role':_text(data.get('role',''),120),
        'interests':_text(data.get('interests',''),600),
        'traits':clean_traits(data.get('traits',[])),
        'slots':clean_slots(data.get('slots',[]),required=True),
        'ai_consent':data.get('ai_consent') is True,
    }
    return result


class MemberDB:
    def __init__(self,path):
        self.path=Path(path)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.lock=threading.RLock()
        with self._connect() as con:
            con.executescript('''
              CREATE TABLE IF NOT EXISTS match_profiles (
                owner_id INTEGER PRIMARY KEY, public_id TEXT UNIQUE NOT NULL,
                alias TEXT NOT NULL, about TEXT NOT NULL, role TEXT NOT NULL,
                skills TEXT NOT NULL, traits TEXT NOT NULL, slots TEXT NOT NULL,
                consent_ai INTEGER NOT NULL DEFAULT 1,
                published INTEGER NOT NULL DEFAULT 1, updated_at INTEGER NOT NULL
              );
              CREATE INDEX IF NOT EXISTS member_published_idx ON match_profiles(published, updated_at DESC);
              CREATE TABLE IF NOT EXISTS match_invites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender_id INTEGER NOT NULL, recipient_id INTEGER NOT NULL,
                note TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
                created_at INTEGER NOT NULL, answered_at INTEGER,
                CHECK(sender_id != recipient_id),
                CHECK(status IN ('pending','accepted','declined'))
              );
              CREATE INDEX IF NOT EXISTS invite_recipient_idx ON match_invites(recipient_id, created_at DESC);
              CREATE INDEX IF NOT EXISTS invite_sender_idx ON match_invites(sender_id, created_at DESC);
              CREATE TABLE IF NOT EXISTS chat_rooms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                invite_id INTEGER UNIQUE NOT NULL,
                user_a INTEGER NOT NULL, user_b INTEGER NOT NULL,
                created_at INTEGER NOT NULL,
                UNIQUE(user_a,user_b), CHECK(user_a < user_b)
              );
              CREATE TABLE IF NOT EXISTS chat_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_id INTEGER NOT NULL REFERENCES chat_rooms(id),
                sender_id INTEGER NOT NULL, body TEXT NOT NULL,
                created_at INTEGER NOT NULL
              );
              CREATE INDEX IF NOT EXISTS chat_messages_room_id ON chat_messages(room_id,id);
              CREATE TABLE IF NOT EXISTS chat_reads (
                user_id INTEGER NOT NULL, room_id INTEGER NOT NULL,
                last_message_id INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL,
                PRIMARY KEY(user_id,room_id)
              );
            ''')
            # Expand the existing table without rebuilding it or changing stored requests.
            # Older versions have a status CHECK allowing only pending/accepted/declined.
            # A cancellation is recorded as declined + cancelled_at; the public API
            # distinguishes it as 'cancelled'. This preserves old DB compatibility.
            columns={row['name'] for row in con.execute('PRAGMA table_info(match_invites)')}
            if 'cancelled_at' not in columns:
                con.execute('ALTER TABLE match_invites ADD COLUMN cancelled_at INTEGER')
            # Compatible with accepted invitations created by v0.10.5.
            con.execute('''INSERT OR IGNORE INTO chat_rooms(invite_id,user_a,user_b,created_at)
               SELECT id, min(sender_id,recipient_id), max(sender_id,recipient_id),
               coalesce(answered_at,created_at) FROM match_invites WHERE status='accepted' ''')

    @contextmanager
    def _connect(self):
        conn=sqlite3.connect(self.path,timeout=10)
        conn.row_factory=sqlite3.Row
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    @staticmethod
    def _row(row, *, own=False):
        if row is None:return None
        result={k:row[k] for k in ('public_id','alias','about','role','skills','updated_at')}
        result['traits']=json.loads(row['traits'])
        result['slots']=json.loads(row['slots'])
        if own:
            result['published']=bool(row['published'])
            result['consent_ai']=bool(row['consent_ai'])
        return result

    def get(self,owner_id):
        with self.lock,self._connect() as con:
            row=con.execute('SELECT * FROM match_profiles WHERE owner_id=?',(owner_id,)).fetchone()
            return self._row(row,own=True)

    def upsert(self,owner_id,data):
        p=clean_profile(data)
        with self.lock,self._connect() as con:
            existing=con.execute('SELECT public_id FROM match_profiles WHERE owner_id=?',(owner_id,)).fetchone()
            public_id=existing['public_id'] if existing else secrets.token_urlsafe(16)
            con.execute('''INSERT INTO match_profiles
                (owner_id,public_id,alias,about,role,skills,traits,slots,consent_ai,published,updated_at)
                VALUES (?,?,?,?,?,?,?,?,1,1,?)
                ON CONFLICT(owner_id) DO UPDATE SET alias=excluded.alias,about=excluded.about,
                role=excluded.role,skills=excluded.skills,traits=excluded.traits,slots=excluded.slots,
                consent_ai=1,published=1,updated_at=excluded.updated_at''',(
                owner_id,public_id,p['alias'],p['about'],p['role'],p['skills'],
                json.dumps(p['traits'],ensure_ascii=False),json.dumps(p['slots'],ensure_ascii=False),int(time.time())))
        return self.get(owner_id)

    def unpublish(self,owner_id):
        with self.lock,self._connect() as con:
            # Capture senders before transitioning their pending requests.  The caller
            # emits SSE *after* commit, so recipients never refetch stale state.
            senders=[row['sender_id'] for row in con.execute(
                "SELECT DISTINCT sender_id FROM match_invites WHERE recipient_id=? AND status='pending'",(owner_id,))]
            con.execute('UPDATE match_profiles SET published=0, consent_ai=0 WHERE owner_id=?',(owner_id,))
            # Existing accepted rooms and messages intentionally stay intact.
            con.execute("UPDATE match_invites SET status='declined', answered_at=? WHERE recipient_id=? AND status='pending'",(int(time.time()),owner_id))
            return senders

    def people(self,owner_id,*,limit=MAX_PUBLIC):
        with self.lock,self._connect() as con:
            rows=con.execute('''SELECT * FROM match_profiles WHERE published=1 AND consent_ai=1
              AND owner_id!=? ORDER BY updated_at DESC LIMIT ?''',(owner_id,min(limit,MAX_PUBLIC))).fetchall()
            return [(row['owner_id'],self._row(row)) for row in rows]

    def owner_for_public_id(self,public_id):
        if not isinstance(public_id,str) or len(public_id)<8 or len(public_id)>64:return None
        with self.lock,self._connect() as con:
            row=con.execute('SELECT owner_id FROM match_profiles WHERE public_id=? AND published=1',
                            (public_id,)).fetchone()
            return row['owner_id'] if row else None

    def send_invite(self,sender_id,target_public_id,note):
        if not isinstance(target_public_id,str) or len(target_public_id)>64 or len(target_public_id)<8:
            raise MemberError('매칭 상대 정보가 올바르지 않습니다.')
        note=_text(note,300,required=True)
        now=int(time.time())
        with self.lock,self._connect() as con:
            sender=con.execute('SELECT 1 FROM match_profiles WHERE owner_id=? AND published=1',(sender_id,)).fetchone()
            target=con.execute('SELECT owner_id FROM match_profiles WHERE public_id=? AND published=1',(target_public_id,)).fetchone()
            if not sender:raise MemberError('매칭 요청 전에 내 프로필을 먼저 공개 등록하세요.',403)
            if not target:raise MemberError('상대방이 매칭 참여를 중단했거나 존재하지 않습니다.',404)
            recipient_id=target['owner_id']
            if recipient_id==sender_id:raise MemberError('본인에게 매칭을 요청할 수 없습니다.',400)
            count=con.execute('SELECT COUNT(*) FROM match_invites WHERE sender_id=? AND created_at>?',(sender_id,now-86400)).fetchone()[0]
            if count>=12:raise MemberError('하루 매칭 요청은 12개까지 보낼 수 있습니다.',429)
            existing=con.execute('''SELECT status,created_at,cancelled_at FROM match_invites WHERE sender_id=? AND recipient_id=?
                ORDER BY id DESC LIMIT 1''',(sender_id,recipient_id)).fetchone()
            if existing:
                if existing['status'] in ('pending','accepted'):
                    raise MemberError('이미 신청한 상대입니다. 신청함에서 상태를 확인해 주세요.',409)
                if existing['cancelled_at'] is not None and existing['cancelled_at']>now-600:
                    raise MemberError('취소한 상대에게는 10분 뒤 다시 신청할 수 있습니다.',409)
                if existing['cancelled_at'] is None and existing['created_at']>now-86400:
                    raise MemberError('최근 거절된 요청은 24시간 뒤 다시 신청할 수 있습니다.',409)
            cur=con.execute('''INSERT INTO match_invites(sender_id,recipient_id,note,created_at)
               VALUES(?,?,?,?)''',(sender_id,recipient_id,note,now))
            return cur.lastrowid

    def invites(self,owner_id):
        with self.lock,self._connect() as con:
            rows=con.execute('''SELECT i.id,i.sender_id,i.recipient_id,i.note,i.status,i.created_at,i.cancelled_at,
                src.alias AS sender_alias,dst.alias AS recipient_alias,
                src.public_id AS sender_public_id,dst.public_id AS recipient_public_id
                FROM match_invites i
                JOIN match_profiles src ON src.owner_id=i.sender_id
                JOIN match_profiles dst ON dst.owner_id=i.recipient_id
                WHERE i.sender_id=? OR i.recipient_id=? ORDER BY i.id DESC LIMIT 80''',(owner_id,owner_id)).fetchall()
            out=[]
            for row in rows:
                incoming=row['recipient_id']==owner_id
                out.append({'id':row['id'],'direction':'received' if incoming else 'sent',
                    'alias':row['sender_alias'] if incoming else row['recipient_alias'],
                    'public_id':row['sender_public_id'] if incoming else row['recipient_public_id'],
                    'note':row['note'],
                    'status':'cancelled' if row['cancelled_at'] is not None else row['status'],
                    'created_at':row['created_at'],
                    # The same thresholds are used by send_invite; this timestamp
                    # allows the UI to unlock automatically without another search.
                    'retry_at':(row['cancelled_at']+600 if row['cancelled_at'] is not None else
                                row['created_at']+86400 if row['status']=='declined' else None)})
            return out

    def cancel_invite(self,sender_id,invite_id):
        # Only the sender may withdraw a pending invite; accepted rooms remain intact.
        if type(invite_id) is not int or invite_id < 1:
            raise MemberError('취소할 신청 번호가 올바르지 않습니다.')
        now=int(time.time())
        with self.lock,self._connect() as con:
            row=con.execute('SELECT sender_id,recipient_id,status FROM match_invites WHERE id=?',
                            (invite_id,)).fetchone()
            if row is None:raise MemberError('해당 매칭 신청을 찾을 수 없습니다.',404)
            if row['sender_id']!=sender_id:raise MemberError('본인이 보낸 매칭 신청만 취소할 수 있습니다.',403)
            if row['status']!='pending':raise MemberError('수락·거절 또는 이미 취소된 신청은 취소할 수 없습니다.',409)
            result=con.execute('''UPDATE match_invites
                SET status='declined', answered_at=?, cancelled_at=? WHERE id=? AND sender_id=? AND status='pending' ''',
                (now,now,invite_id,sender_id))
            if result.rowcount!=1:raise MemberError('이미 처리된 매칭 신청입니다.',409)
            return row['recipient_id']

    def respond(self,recipient_id,invite_id,accept):
        if not isinstance(invite_id,int) or isinstance(invite_id,bool) or invite_id<1 or not isinstance(accept,bool):
            raise MemberError('매칭 요청 응답 형식이 올바르지 않습니다.')
        with self.lock,self._connect() as con:
            row=con.execute('SELECT recipient_id,status FROM match_invites WHERE id=?',(invite_id,)).fetchone()
            if row is None:raise MemberError('매칭 요청이 없습니다.',404)
            if row['recipient_id']!=recipient_id:raise MemberError('본인에게 온 매칭 요청만 응답할 수 있습니다.',403)
            if row['status']!='pending':raise MemberError('이미 처리한 매칭 요청입니다.',409)
            now=int(time.time())
            con.execute('UPDATE match_invites SET status=?,answered_at=? WHERE id=?',
                ('accepted' if accept else 'declined',now,invite_id))
            if accept:
                pair=con.execute('SELECT sender_id,recipient_id FROM match_invites WHERE id=?',(invite_id,)).fetchone()
                con.execute('''INSERT OR IGNORE INTO chat_rooms(invite_id,user_a,user_b,created_at)
                    VALUES(?,?,?,?)''',(invite_id,min(pair),max(pair),now))
            return True


    @staticmethod
    def _room(con,user_id,room_id):
        if type(room_id) is not int or room_id < 1:
            raise MemberError('대화방 번호가 올바르지 않습니다.')
        row=con.execute('''SELECT * FROM chat_rooms WHERE id=? AND (user_a=? OR user_b=?)''',
                        (room_id,user_id,user_id)).fetchone()
        if not row: raise MemberError('접근 가능한 대화방이 없습니다.',403)
        return row

    def rooms(self,user_id):
        with self.lock,self._connect() as con:
            rows=con.execute('''SELECT r.id,r.user_a,r.user_b,r.created_at,
                a.alias AS alias_a,b.alias AS alias_b,
                (SELECT max(m.id) FROM chat_messages m WHERE m.room_id=r.id) AS last_id,
                (SELECT m.body FROM chat_messages m WHERE m.room_id=r.id ORDER BY m.id DESC LIMIT 1) AS last_body,
                (SELECT m.created_at FROM chat_messages m WHERE m.room_id=r.id ORDER BY m.id DESC LIMIT 1) AS last_at,
                coalesce(rd.last_message_id,0) AS seen
                FROM chat_rooms r
                JOIN match_profiles a ON a.owner_id=r.user_a
                JOIN match_profiles b ON b.owner_id=r.user_b
                LEFT JOIN chat_reads rd ON rd.user_id=? AND rd.room_id=r.id
                WHERE r.user_a=? OR r.user_b=?
                ORDER BY coalesce(last_at,r.created_at) DESC, r.id DESC LIMIT 100''',
                (user_id,user_id,user_id)).fetchall()
            return [{'id':r['id'],
               'alias':r['alias_b'] if r['user_a']==user_id else r['alias_a'],
               'last_body':r['last_body'] or '',
               'last_at':r['last_at'] or r['created_at'],
               'unread':con.execute('SELECT count(*) FROM chat_messages WHERE room_id=? AND id>? AND sender_id!=?',
                       (r['id'],r['seen'],user_id)).fetchone()[0]}
               for r in rows]

    def room_members(self,user_id,room_id):
        with self.lock,self._connect() as con:
            room=self._room(con,user_id,room_id)
            return (room['user_a'],room['user_b'])

    def invite_members(self,user_id,invite_id):
        if type(invite_id) is not int or invite_id < 1:
            raise MemberError('매칭 제안 번호가 올바르지 않습니다.')
        with self.lock,self._connect() as con:
            row=con.execute('SELECT sender_id,recipient_id FROM match_invites WHERE id=? AND (sender_id=? OR recipient_id=?)',
                            (invite_id,user_id,user_id)).fetchone()
            if not row:raise MemberError('매칭 제안을 찾지 못했습니다.',403)
            return (row['sender_id'],row['recipient_id'])

    def room_for_invite(self,user_id,invite_id):
        if type(invite_id) is not int or invite_id<1:raise MemberError('매칭 제안 번호가 올바르지 않습니다.')
        with self.lock,self._connect() as con:
            i=con.execute('''SELECT sender_id,recipient_id,status FROM match_invites WHERE id=?
                  AND (sender_id=? OR recipient_id=?)''',(invite_id,user_id,user_id)).fetchone()
            if not i or i['status']!='accepted':raise MemberError('수락한 매칭 제안에만 대화방이 있습니다.',403)
            a,b=sorted((i['sender_id'],i['recipient_id']))
            room=con.execute('SELECT id FROM chat_rooms WHERE user_a=? AND user_b=?',(a,b)).fetchone()
            if not room:raise MemberError('대화방을 찾지 못했습니다.',404)
            return room['id']

    def messages(self,user_id,room_id):
        with self.lock,self._connect() as con:
            room=self._room(con,user_id,room_id)
            peer_id=room['user_b'] if room['user_a']==user_id else room['user_a']
            peer=con.execute('SELECT last_message_id FROM chat_reads WHERE user_id=? AND room_id=?',
                             (peer_id,room_id)).fetchone()
            peer_read_through=peer['last_message_id'] if peer else 0
            rows=con.execute('''SELECT id,sender_id,body,created_at FROM
                  (SELECT id,sender_id,body,created_at FROM chat_messages WHERE room_id=? ORDER BY id DESC LIMIT 80)
                  ORDER BY id ASC''',(room_id,)).fetchall()
            return [{'id':r['id'],'mine':r['sender_id']==user_id,
                     'read':r['sender_id']==user_id and r['id']<=peer_read_through,
                     'body':r['body'],'created_at':r['created_at']} for r in rows]

    def send_message(self,user_id,room_id,body):
        body=_text(body,1200,required=True)
        # Prevent blank/control-only posts and unbounded database growth by one user.
        if not any(ch.isprintable() and not ch.isspace() for ch in body):
            raise MemberError('메시지 내용을 입력하세요.')
        now=int(time.time())
        with self.lock,self._connect() as con:
            self._room(con,user_id,room_id)
            recent=con.execute('''SELECT count(*) FROM chat_messages WHERE room_id=? AND sender_id=? AND created_at>=?''',
                               (room_id,user_id,now-60)).fetchone()[0]
            if recent>=25:raise MemberError('메시지를 너무 자주 보내고 있습니다. 잠시 후 다시 시도하세요.',429)
            cursor=con.execute('''INSERT INTO chat_messages(room_id,sender_id,body,created_at) VALUES(?,?,?,?)''',
                               (room_id,user_id,body,now))
            return {'id':cursor.lastrowid,'mine':True,'body':body,'created_at':now}

    def mark_read(self,user_id,room_id,last_message_id):
        if type(last_message_id) is not int or last_message_id<0:
            raise MemberError('읽음 처리 값이 올바르지 않습니다.')
        with self.lock,self._connect() as con:
            self._room(con,user_id,room_id)
            # Never mark messages not yet delivered in this room as read.
            limit=con.execute('SELECT coalesce(max(id),0) FROM chat_messages WHERE room_id=?',(room_id,)).fetchone()[0]
            acknowledged=min(last_message_id,limit)
            previous=con.execute('SELECT last_message_id FROM chat_reads WHERE user_id=? AND room_id=?',
                                 (user_id,room_id)).fetchone()
            before=previous['last_message_id'] if previous else 0
            if acknowledged<=before:
                return False
            con.execute('''INSERT INTO chat_reads(user_id,room_id,last_message_id,updated_at) VALUES(?,?,?,?)
                ON CONFLICT(user_id,room_id) DO UPDATE SET
                last_message_id=max(chat_reads.last_message_id,excluded.last_message_id),
                updated_at=excluded.updated_at''',(user_id,room_id,acknowledged,int(time.time())))
            return True


def preliminary(query,people):
    """Hard time overlap, then bounded interpretable condition-match ranking.

    The basic scoring is *not* an AI similarity percentage or success probability.
    """
    desired=set(query['slots'])
    ranked=[]
    for owner_id,p in people:
        shared=sorted(desired.intersection(p['slots']),key=lambda s:(DAYS.index(s[0]),PERIODS.index(s[1:])))
        if not shared:continue
        desired_traits=set(query['traits'])
        common_traits=[t for t in p['traits'] if t in desired_traits]
        target_terms=set(query['role'].casefold().split())
        role_terms=set(p['role'].casefold().split())
        role_common=bool(target_terms & role_terms)
        # Used only to order comparable profiles, never shown as a probability.
        score=min(10,len(shared))*5 + 12*len(common_traits) + (20 if role_common else 0)
        ranked.append({'owner_id':owner_id,**p,'common_slots':shared,'common_traits':common_traits,
                       'basic_sort_value':score})
    ranked.sort(key=lambda p:(p['basic_sort_value'],p['updated_at']),reverse=True)
    return ranked[:20]


def semantic_rank(query,people):
    """Gemini semantic embeddings across candidate role/interests/personality, no schedule hallucination."""
    from ai_agent import AIUnavailable, EMBED_MODEL, call_api
    from ai_extended import _cosine
    import os
    if not people:return [],'no_candidates',None
    if not query['ai_consent']:
        return people,'basic','Gemini 전송 동의를 선택하지 않아 시간대·등록 성향 기준으로만 정렬했습니다.'
    if not (query['role'] or query['interests'] or query['traits']):
        return people,'basic','추가 조건이 없어 공통 활동 시간으로 추천했습니다.'
    model=os.environ.get('CAMPUS_GEMINI_EMBED_MODEL',EMBED_MODEL).strip()
    src=f"원하는 역할 {query['role']} / 관심사 {query['interests']} / 원하는 팀원 성향 {' '.join(query['traits'])}"
    texts=[src]+[f"역할 {p['role']} / 경험 {p['about']} / 기술 {p['skills']} / 성향 {' '.join(p['traits'])}"
                 for p in people]
    payload={'requests':[{'model':'models/'+model,'content':{'parts':[{'text':t[:2000]}]},
              'taskType':'SEMANTIC_SIMILARITY','outputDimensionality':768} for t in texts]}
    try:
        reply=call_api(model,payload)
        vectors=reply.get('embeddings') or []
        if len(vectors)!=len(texts):raise AIUnavailable('Embedding 응답 개수가 일치하지 않습니다.',502)
        ref=vectors[0].get('values')
        scored=[]
        for p,raw in zip(people,vectors[1:]):
            similarity=_cosine(ref,raw.get('values'))
            scored.append({**p,'similarity':round(similarity,4)})
        # First respect overlap, then AI semantic relevance and concrete traits.
        scored.sort(key=lambda p:(p['similarity'],len(p['common_slots']),len(p['common_traits'])),reverse=True)
        return scored,'embedding',None
    except (AIUnavailable,ValueError,TypeError,KeyError) as err:
        return people,'basic','Gemini Embedding 분석을 사용할 수 없어 실제 등록된 시간대·성향 기준으로 매칭했습니다. '+str(err)
