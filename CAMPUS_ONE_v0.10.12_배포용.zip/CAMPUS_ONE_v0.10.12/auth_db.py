"""Argon2id accounts and server-side session/profile database for CAMPUS ONE.

Never store passwords, raw session tokens, or login secrets in SQLite.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import sqlite3
import threading
import time
from pathlib import Path

from argon2 import PasswordHasher, Type
from argon2.exceptions import InvalidHashError, VerificationError

SESSION_SECONDS = 12 * 3600
USER_RE = re.compile(r"^[a-zA-Z0-9._-]{3,32}$")
PROFILE_KEYS = frozenset(('campus-one-my-schedule-v1', 'campus-one-study-v1', 'campus-one-extras-v1'))
HASHER = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2, hash_len=32, salt_len=16, type=Type.ID)


class AuthError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def normalize_username(value):
    if not isinstance(value, str) or not USER_RE.fullmatch(value):
        raise AuthError('아이디는 영문/숫자/._-를 사용해 3~32자로 입력하세요.')
    return value.lower()


def validate_password(value):
    if not isinstance(value, str) or len(value) < 12 or len(value) > 128 or len(value.encode('utf-8')) > 512:
        raise AuthError('비밀번호는 12~128자로 입력하세요.')
    if not value.strip():
        raise AuthError('비밀번호를 입력해 주세요.')
    return value


def public_user(row):
    return {'id':row['id'], 'username':row['username'], 'role':row['role'], 'active':bool(row['active'])}


class AuthDB:
    def __init__(self, db_path):
        self.path = Path(db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        if not self.path.exists():
            fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(fd)
        if os.name == 'posix':
            os.chmod(self.path, 0o600)
        with self._connect() as c:
            c.executescript('''
              CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('user','admin')),
                active INTEGER NOT NULL DEFAULT 1,
                failed_attempts INTEGER NOT NULL DEFAULT 0,
                locked_until INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL
              );
              CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                csrf TEXT NOT NULL,
                expires INTEGER NOT NULL
              );
              CREATE TABLE IF NOT EXISTS profiles (
                user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
                content TEXT NOT NULL DEFAULT '{}',
                version INTEGER NOT NULL DEFAULT 0
              );
              CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
            ''')

    def _connect(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA foreign_keys=ON')
        conn.execute('PRAGMA busy_timeout=10000')
        return conn

    def create_user(self, username, password, *, admin=False):
        username = normalize_username(username)
        password = validate_password(password)
        digest = HASHER.hash(password)
        with self.lock, self._connect() as c:
            try:
                if admin and c.execute("SELECT 1 FROM users WHERE role='admin' LIMIT 1").fetchone():
                    raise AuthError('관리자 계정이 이미 있습니다. 기존 관리자 계정을 사용하세요.')
                cursor = c.execute(
                    'INSERT INTO users(username, password_hash, role, created_at) VALUES(?,?,?,?)',
                    (username, digest, 'admin' if admin else 'user', int(time.time())))
                c.execute('INSERT INTO profiles(user_id) VALUES(?)', (cursor.lastrowid,))
                c.commit()
                return cursor.lastrowid
            except sqlite3.IntegrityError:
                raise AuthError('이미 사용 중인 아이디입니다.', 409)

    def login(self, username, password):
        try:
            username = normalize_username(username)
        except AuthError:
            username = ''
        if not isinstance(password, str) or len(password) > 128:
            password = ''
        now = int(time.time())
        with self.lock, self._connect() as c:
            row = c.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
            if not row or not row['active']:
                raise AuthError('아이디 또는 비밀번호를 확인하세요. 잠시 후 다시 시도해 주세요.', 401)
            try:
                matched = HASHER.verify(row['password_hash'], password)
            except (VerificationError, InvalidHashError):
                matched = False
            if not matched:
                # Failed guesses are still throttled by the HTTP per-peer limiter.
                # Never deny a valid password just because a third party generated
                # earlier bad guesses for the username (account lockout DoS).
                count = min(int(row['failed_attempts']) + 1, 5)
                cooldown = now + 300 if count >= 5 else 0
                c.execute('UPDATE users SET failed_attempts=?, locked_until=? WHERE id=?',
                          (count, cooldown, row['id']))
                c.commit()
                raise AuthError('아이디 또는 비밀번호를 확인하세요. 잠시 후 다시 시도해 주세요.', 401)
            updated_hash = HASHER.hash(password) if HASHER.check_needs_rehash(row['password_hash']) else row['password_hash']
            c.execute('UPDATE users SET failed_attempts=0, locked_until=0, password_hash=? WHERE id=?',
                      (updated_hash, row['id']))
            raw_token = secrets.token_urlsafe(32)
            csrf = secrets.token_urlsafe(32)
            # Different browsers/devices may use the same account. A new login
            # must not unexpectedly invalidate another device on F5.
            c.execute('DELETE FROM sessions WHERE expires<=?', (now,))
            c.execute('INSERT INTO sessions(token_hash,user_id,csrf,expires) VALUES(?,?,?,?)',
                      (hashlib.sha256(raw_token.encode()).hexdigest(), row['id'], csrf, now + SESSION_SECONDS))
            # Bounded concurrent sessions mitigate abandoned or leaked cookies;
            # password changes and administrative deactivation still revoke all.
            c.execute('''DELETE FROM sessions WHERE token_hash IN
                 (SELECT token_hash FROM sessions WHERE user_id=?
                  ORDER BY rowid DESC LIMIT -1 OFFSET 5)''', (row['id'],))
            c.commit()
            return public_user(row), raw_token, csrf

    def get_session(self, token):
        if not isinstance(token, str) or len(token) > 100 or not token:
            return None
        digest = hashlib.sha256(token.encode()).hexdigest()
        with self._connect() as c:
            row = c.execute('''SELECT u.id,u.username,u.role,u.active,s.csrf,s.expires FROM sessions s
                               JOIN users u ON u.id=s.user_id
                               WHERE s.token_hash=? AND s.expires>? AND u.active=1''',
                            (digest, int(time.time()))).fetchone()
            return dict(row) if row else None

    def active_user_ids(self, ids):
        """Return active user IDs without exposing account details or changing DB."""
        ids=[int(i) for i in ids if isinstance(i,int) and not isinstance(i,bool) and i>0][:100]
        if not ids:return set()
        placeholders=','.join('?' for _ in ids)
        with self._connect() as c:
            return {row['id'] for row in c.execute(
                f'SELECT id FROM users WHERE active=1 AND id IN ({placeholders})',ids)}

    def logout(self, token):
        if token:
            with self._connect() as c:
                c.execute('DELETE FROM sessions WHERE token_hash=?', (hashlib.sha256(token.encode()).hexdigest(),))
                c.commit()

    def get_profile(self, user_id):
        with self._connect() as c:
            row = c.execute('SELECT version, content FROM profiles WHERE user_id=?', (user_id,)).fetchone()
        if not row:
            raise AuthError('계정의 저장 공간을 찾을 수 없습니다.', 404)
        return {'version': row['version'], 'items':json.loads(row['content'])}

    def put_profile(self, user_id, data, version):
        if not isinstance(data, dict) or not set(data).issubset(PROFILE_KEYS):
            raise AuthError('허용되지 않은 저장 항목입니다.')
        if not isinstance(version, int) or isinstance(version, bool):
            raise AuthError('유효하지 않은 저장 버전입니다.')
        for key, value in data.items():
            if not isinstance(value, str) or len(value.encode('utf-8')) > 256_000:
                raise AuthError('저장 항목의 크기나 형식이 올바르지 않습니다.')
            try:
                json.loads(value)
            except json.JSONDecodeError:
                raise AuthError('저장 데이터는 올바른 JSON이어야 합니다.')
        encoded = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
        if len(encoded.encode('utf-8')) > 400_000:
            raise AuthError('계정 데이터 최대 크기는 400KB입니다.')
        with self.lock, self._connect() as c:
            result = c.execute('UPDATE profiles SET content=?, version=version+1 WHERE user_id=? AND version=?',
                               (encoded, user_id, version))
            if result.rowcount != 1:
                raise AuthError('다른 창에서 데이터가 변경됐습니다. 새로고침 후 다시 시도하세요.', 409)
            c.commit()
        return {'version': version+1}

    def change_password(self, user_id, old, new):
        new = validate_password(new)
        with self.lock, self._connect() as c:
            row = c.execute('SELECT password_hash FROM users WHERE id=? AND active=1', (user_id,)).fetchone()
            try:
                if not row or not HASHER.verify(row['password_hash'], old):
                    raise AuthError('현재 비밀번호가 올바르지 않습니다.', 403)
            except (VerificationError, InvalidHashError):
                raise AuthError('현재 비밀번호가 올바르지 않습니다.', 403)
            c.execute('UPDATE users SET password_hash=? WHERE id=?', (HASHER.hash(new), user_id))
            c.execute('DELETE FROM sessions WHERE user_id=?', (user_id,))
            c.commit()

    def list_users(self):
        with self._connect() as c:
            rows = c.execute('SELECT id,username,role,active,created_at FROM users ORDER BY id DESC LIMIT 500').fetchall()
            return [dict(r) for r in rows]

    def set_active(self, admin_id, user_id, active):
        if not isinstance(user_id, int) or isinstance(user_id, bool) or user_id == admin_id:
            raise AuthError('관리자 자신의 계정은 이 화면에서 변경할 수 없습니다.', 403)
        with self.lock, self._connect() as c:
            user = c.execute('SELECT id,role FROM users WHERE id=?', (user_id,)).fetchone()
            if not user:
                raise AuthError('계정을 찾을 수 없습니다.', 404)
            if user['role'] == 'admin':
                raise AuthError('관리자 계정은 일반 관리 화면에서 변경할 수 없습니다.', 403)
            c.execute('UPDATE users SET active=? WHERE id=?', (int(bool(active)), user_id))
            if not active:
                c.execute('DELETE FROM sessions WHERE user_id=?', (user_id,))
            c.commit()
