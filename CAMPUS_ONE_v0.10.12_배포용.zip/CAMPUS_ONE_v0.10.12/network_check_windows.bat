@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
%PY% network_check.py >"server_diagnostic_096.txt" 2>&1
type "server_diagnostic_096.txt"
echo.
echo Diagnostic report saved as server_diagnostic_096.txt
pause
