@echo off
setlocal
set "CAMPUS_GEMINI_MODEL=gemini-3.5-flash-lite"
chcp 65001 >nul
cd /d "%~dp0"
title CAMPUS ONE v0.10.12 SERVER 18765
set "CAMPUS_ONE_PORT=18765"
if defined GEMINI_API_KEY (
    echo [GEMINI] API key detected
) else (
    echo [GEMINI] API key NOT FOUND
)
set "CAMPUS_ONE_HOST=0.0.0.0"
echo [GEMINI] Model: %CAMPUS_GEMINI_MODEL%
echo =============================================================
echo CAMPUS ONE v0.10.12 - NEW PORT 18765 - AUTH REQUIRED
echo =============================================================
echo.
echo [IMPORTANT] Other PCs must use SERVER_IP:18765, NOT 8765.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py -3"
) else (
  set "PY=python"
)
%PY% -c "import argon2" >nul 2>nul
if errorlevel 1 (
  echo Installing Python dependencies...
  %PY% -m pip install -r requirements.txt
  if errorlevel 1 (
    echo [FAILED] Python dependencies. Check Python installation.
    pause
    exit /b 1
  )
)
echo [CHECK] Checking port 18765 before server start...
%PY% preflight.py
if errorlevel 1 (
  echo.
  echo [STOP] Server launch cancelled: 18765 already in use.
  echo Run network_check_windows.bat to see its owner. Do not confuse with 8765.
  pause
  exit /b 1
)
echo.
echo [START] Starting CAMPUS ONE server. Keep THIS window open.
echo.
%PY% -u server.py
echo.
echo [STOPPED] Server stopped. Read error above if unexpected.
pause
