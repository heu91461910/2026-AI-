"""Create the first administrator through a local console only. No default password."""
import getpass
import os
from pathlib import Path
from auth_db import AuthDB, AuthError

if __name__ == '__main__':
    print('CAMPUS ONE - 최초 관리자 계정 생성 (서버가 아닌 PC에서 실행)')
    store = AuthDB(os.getenv('CAMPUS_ONE_DB_PATH', str(Path(__file__).resolve().parent / 'data' / 'accounts.sqlite3')))
    name = input('관리자 로그인 ID: ').strip()
    password = getpass.getpass('관리자 비밀번호(12자 이상, 화면에 표시되지 않음): ')
    confirm = getpass.getpass('비밀번호 다시 입력: ')
    if password != confirm:
        raise SystemExit('입력한 비밀번호가 서로 다릅니다.')
    try:
        store.create_user(name, password, admin=True)
    except AuthError as exc:
        raise SystemExit(str(exc))
    print(f'관리자 계정 {name} 생성 완료. 로그인 페이지에서 관리자 로그인 메뉴를 사용하세요.')
