"""Opt-in campus recruitment board; kept separate from protected account database.

Only authenticated users may read/write. Entries are user submissions, never
claimed to be official university or live external recruitment information.
"""
from __future__ import annotations
import sqlite3
from contextlib import contextmanager
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit

KINDS = {'club': '동아리', 'society': '학회', 'team': '프로젝트 팀', 'contest': '공모전 팀', 'member': '팀원 프로필'}
FIELDS = {'title': 100, 'description': 1100, 'role': 260, 'schedule': 260, 'apply_url': 400}

class ListingError(ValueError):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def clean_listing(data):
    if not isinstance(data, dict):
        raise ListingError('등록 내용은 JSON 객체여야 합니다.')
    kind = data.get('kind', 'team')
    if kind not in KINDS:
        raise ListingError('모집 유형이 올바르지 않습니다.')
    out = {'kind': kind}
    for key, maxlen in FIELDS.items():
        value = data.get(key, '')
        if not isinstance(value, str) or len(value) > maxlen:
            raise ListingError(f'{key} 입력 길이가 올바르지 않습니다.')
        out[key] = value.strip()
    if len(out['title']) < 2 or len(out['description']) < 10:
        raise ListingError('모집 제목(2자 이상)과 활동 설명(10자 이상)을 입력하세요.')
    url = out['apply_url']
    if url:
        parsed = urlsplit(url)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or any(c.isspace() for c in url):
            raise ListingError('지원 링크는 정상적인 https:// 주소만 허용합니다.')
        if parsed.hostname in ('localhost',) or parsed.hostname.startswith('127.'):
            raise ListingError('내부 주소는 지원 링크로 등록할 수 없습니다.')
    return out


class ActivityDB:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        with self._connect() as con:
            con.executescript('''
            CREATE TABLE IF NOT EXISTS listings (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              owner_id INTEGER NOT NULL,
              kind TEXT NOT NULL,
              title TEXT NOT NULL,
              description TEXT NOT NULL,
              role TEXT NOT NULL DEFAULT '',
              schedule TEXT NOT NULL DEFAULT '',
              apply_url TEXT NOT NULL DEFAULT '',
              created_at INTEGER NOT NULL,
              active INTEGER NOT NULL DEFAULT 1
            );
            CREATE INDEX IF NOT EXISTS listings_active_recent ON listings(active, created_at DESC);
            ''')

    @contextmanager
    def _connect(self):
        c = sqlite3.connect(self.path, timeout=8)
        c.row_factory = sqlite3.Row
        try:
            with c:
                yield c
        finally:
            c.close()

    def list(self, *, limit=80):
        limit = max(1, min(int(limit), 100))
        with self.lock, self._connect() as con:
            return [dict(row) for row in con.execute('''
                SELECT id,owner_id,kind,title,description,role,schedule,apply_url,created_at
                  FROM listings WHERE active=1 ORDER BY created_at DESC,id DESC LIMIT ?
            ''',(limit,)).fetchall()]

    def add(self, owner_id, data):
        d = clean_listing(data)
        with self.lock, self._connect() as con:
            owned = con.execute('SELECT COUNT(*) FROM listings WHERE active=1 AND owner_id=?',(owner_id,)).fetchone()[0]
            if owned >= 20:
                raise ListingError('계정당 공개 모집글은 최대 20개까지 등록할 수 있습니다.', 429)
            cur = con.execute('''INSERT INTO listings(owner_id,kind,title,description,role,schedule,apply_url,created_at)
                VALUES (?,?,?,?,?,?,?,?)''', (owner_id,d['kind'],d['title'],d['description'],d['role'],d['schedule'],d['apply_url'],int(time.time())))
            return cur.lastrowid

    def delete(self, listing_id, owner_id, is_admin=False):
        if not isinstance(listing_id,int) or isinstance(listing_id,bool) or listing_id < 1:
            raise ListingError('모집글 번호가 올바르지 않습니다.')
        with self.lock, self._connect() as con:
            row = con.execute('SELECT owner_id FROM listings WHERE id=? AND active=1',(listing_id,)).fetchone()
            if row is None:
                raise ListingError('모집글을 찾을 수 없습니다.', 404)
            if row['owner_id'] != owner_id and not is_admin:
                raise ListingError('본인 모집글만 삭제할 수 있습니다.', 403)
            con.execute('UPDATE listings SET active=0 WHERE id=?',(listing_id,))
            return True
