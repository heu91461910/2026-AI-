"""Standalone client-PC checker using only Python standard library; no cookies."""
import ipaddress
import json
import socket
import sys
import urllib.error
import urllib.request
PORT=18765
EXPECTED_BUILD='CO1012-20261106-RETRY-SSE-FIX'
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        return None
OPENER=urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())

def check(base,path):
    try:
        with OPENER.open(base+path,timeout=5) as r:
            return r.status,dict(r.headers),r.read(4096)
    except urllib.error.HTTPError as e:
        return e.code,dict(e.headers),e.read(4096)
    except (urllib.error.URLError,socket.timeout,ConnectionError,TimeoutError) as e:
        return None,{},str(e).encode('utf-8','replace')

def main():
    print('====== CAMPUS ONE v0.10.12 CLIENT CHECK (NO LOGIN COOKIE) ======')
    ip=input('Enter SERVER PC LAN IPv4 (example 192.168.0.10): ').strip()
    try:
        addr=ipaddress.ip_address(ip)
        if addr.version!=4 or addr.is_loopback:
            raise ValueError('Use SERVER PC LAN IPv4, not 127.0.0.1')
    except ValueError as e:
        print('Invalid server IP:',e)
        return 2
    base='http://%s:%d'%(ip,PORT)
    print('Target:',base)
    print('NOTE: This checker does not send browser cookies. A valid result should force login.')
    health_code,_,health_body=check(base,'/api/health')
    print('\n[1] /api/health =>',health_code)
    if health_code is None:
        print('ERROR: connection refused/timeout:',health_body.decode('utf-8','replace'))
        print('Check address, server console, firewall, same LAN, Wi-Fi client isolation.')
        return 1
    try: health=json.loads(health_body)
    except ValueError: health={}
    print('Response:',json.dumps(health,ensure_ascii=False))
    if health.get('build')!=EXPECTED_BUILD:
        print('[ERROR] WRONG SERVER / WRONG BUILD. Find the correct server PC and port.')
        return 1
    good=True
    for path,expected in [('/',302),('/index.html',302),('/app.js',401),('/api/state',401),('/login.html',200)]:
        code,headers,body=check(base,path)
        ok=(code==expected)
        if code==302: ok=ok and headers.get('Location')=='/login.html'
        good &= ok
        print('%s -> HTTP %s (expected %s) %s'%(path,code,expected,'PASS' if ok else 'FAIL'))
    if good:
        print('\n[PASS] v0.10.12 is reachable and refuses unauthenticated dashboard access.')
        print('If a normal browser still opens dashboard without login, inspect /api/health authenticated=true or old server/browser cache.')
        return 0
    print('\n[FAIL] Unexpected unauthenticated response; share these results for further repair.')
    return 1
if __name__=='__main__':sys.exit(main())
