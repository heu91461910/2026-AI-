@echo off
setlocal
chcp 65001 >nul
cls
echo ====================================================
echo CAMPUS ONE v0.10.12 : port 18765 PRIVATE LAN only
echo ====================================================
echo.
echo This is intended ONLY for a TRUSTED HOME PRIVATE network.
echo Never run it on shared/public/school Wi-Fi without permission.
echo It cannot defeat school Wi-Fi client isolation.
echo.
fltmc >nul 2>&1
if errorlevel 1 (
 echo [ERROR] Right click and Run as administrator.
 pause
 exit /b 1
)
powershell -NoProfile -Command "Get-NetConnectionProfile | Format-Table InterfaceAlias,NetworkCategory -AutoSize"
echo.
set /p ANSWER=Allow TCP 18765 only from local subnet on PRIVATE profile? [Y/N]: 
if /i not "%ANSWER%"=="Y" (echo Cancelled.&pause&exit /b 0)
netsh advfirewall firewall add rule name="CAMPUS ONE 18765 Private LAN" dir=in action=allow protocol=TCP localport=18765 remoteip=localsubnet profile=private
if errorlevel 1 (echo [ERROR] Firewall rule failed) else (echo [OK] Rule added.)
echo Undo via: netsh advfirewall firewall delete rule name="CAMPUS ONE 18765 Private LAN"
pause
