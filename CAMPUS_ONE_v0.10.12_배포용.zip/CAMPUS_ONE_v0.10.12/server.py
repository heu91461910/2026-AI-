"""CAMPUS ONE v0.10.12 AI, authenticated messaging, read receipts and SSE."""
from __future__ import annotations

import json
import os
import hmac
import ipaddress
import posixpath
import time
import threading
import secrets
from collections import defaultdict, deque
from http import cookies
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, unquote

from auth_db import AuthDB, AuthError, SESSION_SECONDS, public_user
from activity_db import ActivityDB, ListingError

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
STATIC = ROOT / 'static'
APP_VERSION = '0.10.12'
APP_BUILD = 'CO1012-20261106-RETRY-SSE-FIX'
COOKIE_NAME = 'campus_session_v096'
PUBLIC_ASSETS = frozenset({'/login.html', '/login.js', '/style.css'})
SERVER_INSTANCE = secrets.token_hex(6)  # Change each time server.py starts
MAX_BODY = 15 * 1024 * 1024
DB = AuthDB(os.getenv('CAMPUS_ONE_DB_PATH', str(DATA / 'accounts.sqlite3')))
RATES_LOCK = threading.RLock()
ATTEMPTS = defaultdict(deque)
ACTIVITIES_LOCK = threading.RLock()
ACTIVITIES = None
MEMBERS_LOCK = threading.RLock()
MEMBERS = None
MATCH_LIMIT_LOCK = threading.RLock()
MATCH_QUERIES = defaultdict(deque)
EVENT_COND = threading.Condition()
EVENTS_BY_USER = defaultdict(lambda: deque(maxlen=128))
EVENT_SEQUENCE = 0
STREAM_LIMIT = threading.BoundedSemaphore(64)


def publish(user_ids,kind):
    """Signal only authorized participants to refetch protected resources."""
    global EVENT_SEQUENCE
    with EVENT_COND:
        EVENT_SEQUENCE += 1
        event=(EVENT_SEQUENCE,kind)
        for uid in set(user_ids):
            if type(uid) is int and uid > 0:
                EVENTS_BY_USER[uid].append(event)
        EVENT_COND.notify_all()



def activity_store():
    # Lazy creation ensures importing the server never mutates the protected
    # accounts.sqlite3; board data lives in its own SQLite database.
    global ACTIVITIES
    with ACTIVITIES_LOCK:
        if ACTIVITIES is None:
            path = os.getenv('CAMPUS_ONE_ACTIVITY_DB_PATH',str(DATA/'activities.sqlite3'))
            ACTIVITIES = ActivityDB(path)
        return ACTIVITIES



def member_store():
    # Match profiles/invites are separate from the protected accounts database.
    global MEMBERS
    from member_match import MemberDB
    with MEMBERS_LOCK:
        if MEMBERS is None:
            path=os.getenv('CAMPUS_ONE_MEMBER_DB_PATH',str(DATA/'members.sqlite3'))
            MEMBERS=MemberDB(path)
        return MEMBERS


def too_many_attempts(ip):
    """Restrict unauthenticated POSTs per local peer: 12 per 5 minutes."""
    now = time.monotonic()
    with RATES_LOCK:
        items = ATTEMPTS[ip]
        while items and items[0] <= now - 300:
            items.popleft()
        if len(items) >= 12:
            return True
        items.append(now)
        return False


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(STATIC), **kwargs)

    def log_message(self, fmt, *args):
        print('[CAMPUS ONE]', fmt % args)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        super().end_headers()

    def send_json(self, data, status=200, cookie=None):
        body = json.dumps(data, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        if cookie:
            self.send_header('Set-Cookie', cookie)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def read_json(self):
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except (TypeError, ValueError):
            raise AuthError('요청 본문 길이가 올바르지 않습니다.')
        if length <= 0 or length > MAX_BODY:
            raise AuthError('요청 크기가 제한을 초과했습니다.', 413)
        if 'application/json' not in self.headers.get('Content-Type', '').lower():
            raise AuthError('JSON 형식의 요청만 허용됩니다.', 415)
        try:
            result = json.loads(self.rfile.read(length))
            if not isinstance(result, dict):
                raise ValueError('object expected')
            return result
        except (ValueError, UnicodeDecodeError):
            raise AuthError('올바른 JSON 객체를 입력하세요.')

    def cookie_token(self):
        value = self.headers.get('Cookie', '')
        if len(value) > 2048:
            return ''
        cookie = cookies.SimpleCookie()
        try:
            cookie.load(value)
            return cookie[COOKIE_NAME].value if COOKIE_NAME in cookie else ''
        except cookies.CookieError:
            return ''

    def session(self, *, required=True, admin=False):
        item = DB.get_session(self.cookie_token())
        if not item:
            if required:
                raise AuthError('로그인이 필요합니다.', 401)
            return None
        if admin and item['role'] != 'admin':
            raise AuthError('관리자만 사용할 수 있습니다.', 403)
        return item

    def csrf(self, session):
        provided = self.headers.get('X-CSRF-Token', '')
        if not isinstance(provided, str) or not hmac.compare_digest(provided, session['csrf']):
            raise AuthError('요청 인증 토큰이 유효하지 않습니다. 새로 로그인하세요.', 403)

    def same_origin(self):
        host = self.headers.get('Host', '')
        hostname = host.rsplit(':', 1)[0].strip('[]').lower()
        try:
            address = ipaddress.ip_address(hostname)
            allowed = address.is_loopback or address.is_private
        except ValueError:
            allowed = hostname == 'localhost'
        if not allowed or any(c in host for c in '/\\@ '):
            raise AuthError('허용되지 않은 접속 주소입니다.', 403)
        origin = self.headers.get('Origin')
        if origin and origin not in ('http://' + host, 'https://' + host):
            raise AuthError('다른 출처에서 온 요청은 허용하지 않습니다.', 403)
        if self.headers.get('Sec-Fetch-Site') == 'cross-site':
            raise AuthError('외부 사이트에서 보낸 요청은 거부됩니다.', 403)

    def redirect(self, target):
        self.send_response(302)
        self.send_header('Location', target)
        self.end_headers()

    def session_cookie(self, token=None):
        # Only trust an explicit local deployment setting, never a client-sent
        # X-Forwarded-Proto header. Reverse proxy setup needs independent review.
        secure = '; Secure' if os.environ.get('CAMPUS_ONE_HTTPS_PROXY', '') == '1' else ''
        if token is None:
            return f'{COOKIE_NAME}=; HttpOnly; Path=/; SameSite=Strict; Max-Age=0' + secure
        return f'{COOKIE_NAME}={token}; HttpOnly; Path=/; SameSite=Strict; Max-Age={SESSION_SECONDS}' + secure

    @staticmethod
    def safe_path(request_path):
        # Normalize encoded paths and dot-segments *before* access control.
        # SimpleHTTPRequestHandler otherwise maps /x/../index.html to index.html.
        raw = urlsplit(request_path).path
        decoded = unquote(raw)
        if any(c in decoded for c in ('\\', '\x00')):
            raise AuthError('허용되지 않은 파일 경로입니다.', 400)
        return posixpath.normpath('/' + decoded.lstrip('/'))

    def stream_events(self):
        s = self.session()
        if not STREAM_LIMIT.acquire(blocking=False):
            raise AuthError('실시간 연결이 많습니다. 잠시 후 다시 연결하세요.',503)
        uid=s['id']
        raw=self.headers.get('Last-Event-ID','')
        try:
            # Sequence numbers are specific to this server process. A browser
            # reconnecting after restart must discard the previous process ID.
            epoch, seq = raw.split(':',1)
            last_id=max(0,int(seq)) if epoch == SERVER_INSTANCE and len(raw)<40 else 0
        except (ValueError,AttributeError):
            last_id=0
        try:
            self.send_response(200)
            self.send_header('Content-Type','text/event-stream; charset=utf-8')
            self.send_header('X-Accel-Buffering','no')
            self.send_header('Connection','keep-alive')
            self.end_headers()
            self.wfile.write(b'event: ready\ndata: {}\n\n')
            self.wfile.flush()
            # Hold the open response; send changes immediately and heartbeat
            # so dropped browsers reconnect automatically.
            while True:
                if DB.get_session(self.cookie_token()) is None:
                    break
                with EVENT_COND:
                    pending=[e for e in EVENTS_BY_USER.get(uid,()) if e[0]>last_id]
                    if not pending:
                        EVENT_COND.wait(timeout=12)
                        pending=[e for e in EVENTS_BY_USER.get(uid,()) if e[0]>last_id]
                if pending:
                    for seq,kind in pending:
                        payload=json.dumps({'type':kind},ensure_ascii=False)
                        self.wfile.write(f'id: {SERVER_INSTANCE}:{seq}\nevent: update\ndata: {payload}\n\n'.encode('utf-8'))
                        last_id=seq
                else:
                    self.wfile.write(b': keepalive\n\n')
                self.wfile.flush()
        except (BrokenPipeError,ConnectionResetError,OSError):
            pass
        finally:
            STREAM_LIMIT.release()

    def do_GET(self):
        try:
            path = self.safe_path(self.path)
            if path == '/api/health':
                # A non-sensitive diagnostic indicating WHICH server responds,
                # and whether this particular browser has a valid session.
                # No usernames, tokens, account data, or secrets are returned.
                return self.send_json({'service':'CAMPUS ONE','version':APP_VERSION,
                                       'build':APP_BUILD,'login_required':True,
                                       'authenticated':bool(self.session(required=False)),
                                       'instance_id':SERVER_INSTANCE,
                                       'port':self.server.server_port})
            if path == '/api/chat/events':
                self.same_origin()
                return self.stream_events()
            if path == '/api/auth/me':
                s = self.session()
                return self.send_json({'user':public_user(s), 'csrf':s['csrf']})
            if path == '/api/ai/members/me':
                s = self.session()
                return self.send_json({'profile':member_store().get(s['id'])})
            if path == '/api/ai/members/invites':
                s = self.session()
                return self.send_json({'items':member_store().invites(s['id']), 'server_now':int(time.time())})
            if path == '/api/ai/listings':
                s = self.session()
                entries = activity_store().list()
                public = [{**{k:v for k,v in x.items() if k != 'owner_id'},
                           'can_delete': x['owner_id']==s['id'] or s['role']=='admin'} for x in entries]
                return self.send_json({'items':public,'source':'사용자가 직접 등록한 모집글이며 공식 공고가 아닙니다.'})
            if path == '/api/chat/rooms':
                session=self.session()
                return self.send_json({'rooms':member_store().rooms(session['id'])})
            if path == '/api/chat/messages':
                from urllib.parse import parse_qs
                session=self.session()
                query=parse_qs(urlsplit(self.path).query)
                try: room_id=int(query.get('room_id',[''])[0])
                except (TypeError,ValueError): raise AuthError('대화방 번호가 올바르지 않습니다.',400)
                from member_match import MemberError
                try:return self.send_json({'items':member_store().messages(session['id'],room_id)})
                except MemberError as e:raise AuthError(str(e),e.status)
            if path == '/api/chat/room-for-invite':
                from urllib.parse import parse_qs
                session=self.session()
                query=parse_qs(urlsplit(self.path).query)
                try: invite_id=int(query.get('invite_id',[''])[0])
                except (TypeError,ValueError):raise AuthError('매칭 요청 번호가 올바르지 않습니다.',400)
                from member_match import MemberError
                try:return self.send_json({'room_id':member_store().room_for_invite(session['id'],invite_id)})
                except MemberError as e:raise AuthError(str(e),e.status)
            if path == '/api/admin/users':
                self.session(admin=True)
                return self.send_json({'users':DB.list_users()})
            if path.startswith('/api/'):
                raise AuthError('요청한 기능이 없습니다.', 404)
            if path in PUBLIC_ASSETS:
                # Exact allowlist, including for unauthenticated users.
                self.path = path
                return super().do_GET()
            if not self.session(required=False):
                if path == '/' or path.endswith('.html') or '.' not in path.rsplit('/', 1)[-1]:
                    return self.redirect('/login.html')
                raise AuthError('로그인이 필요합니다.', 401)
            # Use normalized path for the filesystem operation too, preventing
            # path variants from bypassing the authorization above.
            self.path = '/index.html' if path == '/' else path
            return super().do_GET()
        except AuthError as exc:
            return self.send_json({'error':str(exc)}, exc.status)
        except (OSError, ValueError, json.JSONDecodeError):
            return self.send_json({'error':'데이터를 읽는 중 오류가 발생했습니다.'}, 500)

    def do_HEAD(self):
        try:
            path = self.safe_path(self.path)
            if path not in PUBLIC_ASSETS and not self.session(required=False):
                self.send_response(401)
                self.end_headers()
                return
            self.path = '/index.html' if path == '/' else path
            return super().do_HEAD()
        except AuthError as exc:
            self.send_response(exc.status)
            self.end_headers()

    def do_POST(self):
        path = urlsplit(self.path).path
        try:
            self.same_origin()
            if path not in ('/api/auth/register', '/api/auth/login', '/api/auth/logout',
                            '/api/auth/change-password', '/api/admin/set-active', '/api/ai/analyze',
                            '/api/ai/interview','/api/ai/listings/create','/api/ai/listings/delete',
                            '/api/ai/members/profile','/api/ai/members/unpublish',
                            '/api/ai/members/search','/api/ai/members/invite',
                            '/api/ai/members/respond', '/api/ai/members/cancel',
                            '/api/chat/send', '/api/chat/read'):
                raise AuthError('요청한 기능이 없습니다.', 404)
            if path in ('/api/auth/register', '/api/auth/login') and too_many_attempts(self.client_address[0]):
                raise AuthError('요청이 너무 많습니다. 잠시 후 다시 시도하세요.', 429)
            s = None
            if path not in ('/api/auth/register', '/api/auth/login'):
                s = self.session(admin=path == '/api/admin/set-active')
                self.csrf(s)
            obj = self.read_json()
            if path in ('/api/auth/register', '/api/auth/login'):
                username = obj.get('username','')
                password = obj.get('password','')
                if path == '/api/auth/register':
                    DB.create_user(username, password, admin=False)
                user, token, csrf = DB.login(username, password)
                if obj.get('admin_login') and user['role'] != 'admin':
                    DB.logout(token)
                    raise AuthError('관리자 계정이 아닙니다.', 403)
                return self.send_json({'user':user, 'csrf':csrf}, cookie=self.session_cookie(token))
            if path == '/api/auth/logout':
                DB.logout(self.cookie_token())
                return self.send_json({'ok':True}, cookie=self.session_cookie())
            if path == '/api/auth/change-password':
                DB.change_password(s['id'], obj.get('old_password'), obj.get('new_password'))
                return self.send_json({'ok':True, 'relogin':True}, cookie=self.session_cookie())
            if path == '/api/admin/set-active':
                DB.set_active(s['id'], obj.get('user_id'), obj.get('active'))
                return self.send_json({'ok':True})
            if path in ('/api/chat/send','/api/chat/read'):
                from member_match import MemberError
                try:
                    if path == '/api/chat/send':
                        store=member_store()
                        msg=store.send_message(s['id'],obj.get('room_id'),obj.get('body',''))
                        publish(store.room_members(s['id'],obj['room_id']),'chat')
                        return self.send_json({'message':msg})
                    store=member_store()
                    room_id=obj.get('room_id')
                    advanced=store.mark_read(s['id'],room_id,obj.get('last_id'))
                    if advanced:
                        publish(store.room_members(s['id'],room_id),'read')
                    return self.send_json({'ok':True,'advanced':advanced})
                except MemberError as e:
                    raise AuthError(str(e),e.status)
            if path.startswith('/api/ai/members/'):
                from member_match import MemberError, clean_query, preliminary, semantic_rank
                try:
                    store=member_store()
                    if path == '/api/ai/members/profile':
                        return self.send_json({'profile':store.upsert(s['id'],obj)})
                    if path == '/api/ai/members/unpublish':
                        affected_senders=store.unpublish(s['id'])
                        # Pending requests are now declined; notify their senders
                        # and the current user without touching existing chats.
                        publish((*affected_senders,s['id']),'invite')
                        return self.send_json({'ok':True})
                    if path == '/api/ai/members/search':
                        query=clean_query(obj)
                        people=store.people(s['id'])
                        active=DB.active_user_ids([owner for owner,_ in people])
                        eligible=preliminary(query,[(owner,p) for owner,p in people if owner in active])
                        if query['ai_consent'] and eligible:
                            # A voluntary Gemini query can consume free-tier quota;
                            # keep shared-campus API keys from being drained rapidly.
                            with MATCH_LIMIT_LOCK:
                                now=time.monotonic()
                                events=MATCH_QUERIES[s['id']]
                                while events and events[0] < now - 900:
                                    events.popleft()
                                if len(events)>=20:
                                    raise AuthError('AI 팀원 검색은 15분당 최대 20회입니다. 동의를 해제하면 기본 조건 검색은 계속 가능합니다.',429)
                                events.append(now)
                        ranked,method,warning=semantic_rank(query,eligible)
                        public=[]
                        for p in ranked[:12]:
                            public.append({k:v for k,v in p.items() if k in (
                                'public_id','alias','about','role','skills','traits','slots',
                                'common_slots','common_traits','similarity')})
                        return self.send_json({'matches':public,'method':method,
                          'warning':warning or '', 'count':len(public),
                          'rule':'공통으로 선택한 시간대가 없는 학생은 결과에서 제외합니다. '                           '의미 유사도는 합격 확률이 아닙니다.'})
                    if path == '/api/ai/members/invite':
                        target=store.owner_for_public_id(obj.get('public_id'))
                        if target is None or target not in DB.active_user_ids([target]):
                            raise AuthError('상대방이 매칭 참여 중이 아니거나 현재 사용할 수 없는 계정입니다.',404)
                        new_id=store.send_invite(s['id'],obj.get('public_id'),obj.get('note',''))
                        publish((s['id'],target),'invite')
                        return self.send_json({'id':new_id})
                    if path == '/api/ai/members/respond':
                        ok=store.respond(s['id'],obj.get('id'),obj.get('accept'))
                        publish(store.invite_members(s['id'],obj['id']),'invite')
                        return self.send_json({'ok':ok})
                    if path == '/api/ai/members/cancel':
                        target=store.cancel_invite(s['id'],obj.get('id'))
                        publish((s['id'],target),'invite')
                        return self.send_json({'ok':True,'status':'cancelled'})
                except MemberError as e:
                    raise AuthError(str(e),e.status)
            if path == '/api/ai/listings/create':
                if len(json.dumps(obj,ensure_ascii=False)) > 5000:
                    raise AuthError('모집글 입력이 너무 깁니다.',413)
                try:
                    row_id=activity_store().add(s['id'],obj)
                    return self.send_json({'ok':True,'id':row_id})
                except ListingError as e:
                    raise AuthError(str(e),e.status)
            if path == '/api/ai/listings/delete':
                try:
                    activity_store().delete(obj.get('id'),s['id'],s['role']=='admin')
                    return self.send_json({'ok':True})
                except ListingError as e:
                    raise AuthError(str(e),e.status)
            if path == '/api/ai/interview':
                from ai_agent import AIUnavailable
                from ai_extended import interview
                if len(json.dumps(obj,ensure_ascii=False)) > 19000:
                    raise AuthError('면접 입력이 너무 깁니다.',413)
                try:
                    return self.send_json(interview(obj))
                except AIUnavailable as e:
                    return self.send_json({'error':str(e),'retryable':e.retryable,'error_code':e.status}, e.status if 400<=e.status<=599 else 503)
            if path == '/api/ai/analyze':
                from ai_agent import generate, AIUnavailable
                task = obj.get('task')
                if task not in ('career','match'):
                    raise AuthError('지원하지 않는 AI 분석 유형입니다.', 400)
                profile=obj.get('profile',{})
                courses=obj.get('courses',[])
                candidates=obj.get('candidates',[])
                if not isinstance(profile,dict) or not isinstance(courses,list) or not isinstance(candidates,list):
                    raise AuthError('AI 분석 데이터 형식이 올바르지 않습니다.', 400)
                if len(json.dumps(obj,ensure_ascii=False)) > 22000:
                    raise AuthError('AI 분석 입력이 너무 깁니다.', 413)
                detail = obj.get('detail', 'deep')
                if detail not in ('standard', 'deep'):
                    raise AuthError('AI 분석 상세도 설정이 올바르지 않습니다.', 400)
                try:
                    if task == 'match':
                        from ai_extended import match
                        outcome=match(profile,candidates,detail)
                        return self.send_json({**outcome,'model':'Gemini','source':'사용자 입력 및 등록된 모집 후보','detail':detail})
                    from ai_extended import normalized_candidates
                    collected=normalized_candidates(candidates)
                    text_candidates=[f"{c['title']} | {c.get('description','')} | {c.get('role','')} | {c.get('schedule','')}" for c in collected[:12]]
                    return self.send_json({'answer':generate(task,profile,courses,text_candidates,detail=detail),'model':'Gemini','source':'사용자 입력·선택된 공개 모집 후보','detail':detail})
                except AIUnavailable as e:
                    return self.send_json({'error':str(e),'retryable':e.retryable,'error_code':e.status}, e.status if 400 <= e.status <= 599 else 503)
        except AuthError as exc:
            return self.send_json({'error':str(exc)}, exc.status)
        except (ValueError, TypeError, KeyError, UnicodeDecodeError) as exc:
            return self.send_json({'error':str(exc)},400)
        except Exception as exc:
            self.log_message('Internal API error %s: %s', path, type(exc).__name__)
            return self.send_json({'error':'서버 처리 중 오류가 발생했습니다.'}, 500)


if __name__ == '__main__':
    import webbrowser
    port = int(os.getenv('CAMPUS_ONE_PORT','18765'))
    host = os.getenv('CAMPUS_ONE_HOST','0.0.0.0')
    print(f'\nCAMPUS ONE v{APP_VERSION} | 서버 바인딩: {host}:{port}')
    print(f'서버 PC: http://127.0.0.1:{port}/')
    print(f'다른 PC: http://서버PC_IP:{port}/  (0.0.0.0은 접속 주소가 아닙니다)')
    print('관리자는 별도의 create_admin.py로 생성하세요. 초기 관리자/비밀번호는 제공하지 않습니다.')
    print('인트라넷 전용입니다. 인터넷에 직접 공개하지 마세요.')
    print('진단: http://127.0.0.1:%d/api/health' % port)
    print('이 서버 인스턴스: ' + SERVER_INSTANCE)
    print('다른 PC에서 연결이 안 되면 network_check_windows.bat 실행.\n')
    try:
        # Bind before opening the browser. Otherwise an older server on this port
        # may be shown even though this new process could not start.
        server = ThreadingHTTPServer((host,port), Handler)
        print('서버 바인딩 성공: %s:%s (모든 로컬 IP 사용 가능)' % (host,port),flush=True)
        webbrowser.open(f'http://127.0.0.1:{port}')
        server.serve_forever()
    except KeyboardInterrupt:
        print('\n종료했습니다.')
    except OSError as exc:
        print('서버 시작 실패:',exc)
        print('포트 %s가 점유됐거나 주소를 열 수 없습니다. 기존 서버를 종료하고 다시 실행하세요.' % port)
        print('network_check_windows.bat으로 현재 포트에 응답하는 버전을 확인해 주세요.')
