/* AI-only authentication. Credentials are never stored in JS. */
'use strict';
const CampusAuth = (()=>{
  const $=id=>document.getElementById(id);
  let csrfToken='',currentUser=null,mode='login';
  let readyResolver=null,initialized=false,accountHandlersWired=false;
  const request=async(path,body,csrf=true)=>{
    const res=await fetch(path,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json',...(csrf?{'X-CSRF-Token':csrfToken}:{})},body:JSON.stringify(body)});
    const data=await res.json();
    if(!res.ok)throw new Error(data.error||`서버 오류 (${res.status})`);
    return data;
  };
  function setMessage(msg){$('authAlert').textContent=msg||'';}
  function setMode(next){
    mode=next;setMessage('');
    $('authResumePanel').hidden=true;
    $('authLoginForm').hidden=mode==='register';
    $('authRegisterForm').hidden=mode!=='register';
    $('authSwitchRegister').hidden=mode==='register';
    $('authSwitchLogin').hidden=mode==='login';
    $('authSwitchAdmin').hidden=mode==='admin';
    $('authHeading').textContent=mode==='register'?'새 계정을 만드세요.':mode==='admin'?'관리자 로그인':'다시 만나 반갑습니다.';
    $('authSubtitle').textContent=mode==='register'?'학생 계정은 일반 사용자 권한으로 생성됩니다.':mode==='admin'?'별도로 생성한 관리자 계정으로 로그인하세요.':'AI 분석과 팀 활동, 대화방을 계정으로 관리하세요.';
    $('authLoginButton').textContent=mode==='admin'?'관리자 로그인':'로그인';
  }
  function unlockApp(){
    document.body.classList.remove('auth-locked');
    $('authGate').hidden=true;
  }
  async function loadUser(me,{unlock=true}={}){
    currentUser=me.user;csrfToken=me.csrf;
    if(unlock)unlockApp();
    $('accountName').textContent=currentUser.username+(currentUser.role==='admin'?' · 관리자':'');
    $('profileAvatar').textContent=currentUser.username.slice(0,2).toUpperCase();
    $('accountIdentity').textContent=`${currentUser.username} · ${currentUser.role==='admin'?'관리자':'일반 사용자'}`;
    for(const el of document.querySelectorAll('.admin-only'))el.hidden=currentUser.role!=='admin';
    if(accountHandlersWired)return;
    accountHandlersWired=true;
    $('accountOpen').addEventListener('click',()=>{$('accountModal').hidden=false;});
    $('accountClose').addEventListener('click',()=>{$('accountModal').hidden=true;});
    $('accountLogout').addEventListener('click',logout);
    $('accountPasswordForm').addEventListener('submit',changePassword);
    $('adminRefresh').addEventListener('click',refreshUsers);
    $('adminUserRows').addEventListener('click',toggleUser);
  }
  async function login(e){
    e.preventDefault();const btn=$('authLoginButton');btn.disabled=true;setMessage('로그인 중…');
    try{
      const data=await request('/api/auth/login',{username:$('authLoginId').value,password:$('authLoginPassword').value,admin_login:mode==='admin'},false);
      $('authLoginPassword').value='';
      await loadUser(data);
      readyResolver?.();readyResolver=null;
    }catch(err){setMessage(err.message);}finally{btn.disabled=false;}
  }
  async function register(e){
    e.preventDefault();const btn=$('authRegisterButton');btn.disabled=true;
    const pass=$('authRegisterPassword').value;
    if(pass!==$('authRegisterConfirm').value){setMessage('비밀번호 확인이 일치하지 않습니다.');btn.disabled=false;return;}
    try{
      const data=await request('/api/auth/register',{username:$('authRegisterId').value,password:pass},false);
      $('authRegisterPassword').value='';$('authRegisterConfirm').value='';
      await loadUser(data);
      readyResolver?.();readyResolver=null;
    }catch(err){setMessage(err.message);}finally{btn.disabled=false;}
  }
  function wire(){
    if(initialized)return;initialized=true;
    $('authLoginForm').addEventListener('submit',login);
    $('authRegisterForm').addEventListener('submit',register);
    $('authSwitchRegister').addEventListener('click',()=>setMode('register'));
    $('authSwitchLogin').addEventListener('click',()=>setMode('login'));
    $('authSwitchAdmin').addEventListener('click',()=>setMode('admin'));
    $('authResumeContinue').addEventListener('click',()=>{
      unlockApp();
      readyResolver?.();readyResolver=null;
    });
    $('authResumeSwitch').addEventListener('click',async()=>{
      const button=$('authResumeSwitch');button.disabled=true;
      try{
        await request('/api/auth/logout',{},true);
        currentUser=null;csrfToken='';
        $('authResumePanel').hidden=true;
        setMode('login');
        $('authLoginId').value='';$('authLoginPassword').value='';
        $('authLoginId').focus();
      }catch(err){setMessage('계정 전환 실패: '+err.message);}finally{button.disabled=false;}
    });
    setMode('login');
  }
  async function ready(){
    wire();
    try{
      const res=await fetch('/api/auth/me',{credentials:'same-origin',cache:'no-store'});
      if(res.ok){
        const me=await res.json();
        // A valid HttpOnly cookie must survive F5: resume directly, no login gate.
        // The existing "switch account" action remains available through logout.
        await loadUser(me,{unlock:true});
        return;
      }
      if(res.status!==401)throw new Error(`계정 확인 실패 (${res.status})`);
    }catch(e){setMessage('계정 확인 오류: '+e.message+' · 서버 실행 상태를 확인해 주세요.');}
    $('authGate').hidden=false;
    await new Promise(resolve=>{readyResolver=resolve;});
  }
  async function logout(){
    const btn=$('accountLogout');btn.disabled=true;
    try{
      await request('/api/auth/logout',{},true);
      location.reload();
    }catch(e){alert('로그아웃 전 데이터 저장을 확인해 주세요: '+e.message);btn.disabled=false;}
  }
  async function changePassword(e){
    e.preventDefault();
    const message=$('accountModalMessage');message.textContent='';
    try{
      await request('/api/auth/change-password',{old_password:$('oldPassword').value,new_password:$('newPassword').value},true);
      $('oldPassword').value='';$('newPassword').value='';alert('비밀번호가 변경되었습니다. 다시 로그인해 주세요.');location.reload();
    }catch(err){message.textContent=err.message;}
  }
  async function refreshUsers(){
    if(currentUser?.role!=='admin')return;
    const box=$('adminUserRows');box.textContent='불러오는 중…';
    try{
      const res=await fetch('/api/admin/users',{credentials:'same-origin',cache:'no-store'});
      const data=await res.json();if(!res.ok)throw new Error(data.error||'권한이 없습니다.');
      box.replaceChildren();
      for(const u of data.users){
        const row=document.createElement('div');row.className='admin-user-row';
        const info=document.createElement('div');const name=document.createElement('strong');name.textContent=u.username;
        const meta=document.createElement('small');meta.textContent=`${u.role==='admin'?'관리자':'일반 회원'} · ${u.active?'사용 가능':'비활성화'} · UID ${u.id}`;
        info.append(name,meta);row.append(info);
        if(u.role==='user'){
          const btn=document.createElement('button');btn.className='outline-button';btn.textContent=u.active?'비활성화':'다시 활성화';
          btn.dataset.userId=String(u.id);btn.dataset.setActive=u.active?'false':'true';row.append(btn);
        }
        box.append(row);
      }
    }catch(err){box.textContent=err.message;}
  }
  async function toggleUser(e){
    const btn=e.target.closest('[data-user-id]');if(!btn)return;
    const active=btn.dataset.setActive==='true';
    if(!confirm(`이 계정을 ${active?'활성화':'비활성화'}하시겠습니까?`))return;
    btn.disabled=true;
    try{await request('/api/admin/set-active',{user_id:Number(btn.dataset.userId),active},true);await refreshUsers();}
    catch(err){alert(err.message);btn.disabled=false;}
  }
  return {ready,csrf:()=>csrfToken,user:()=>currentUser,refreshUsers};
})();
