/* CAMPUS ONE v0.10.12: AI-only workspace navigation. */
'use strict';
const VIEWS={'ai-career':'AI 커리어 로드맵','ai-match':'AI 동아리·팀 매칭','ai-interview':'AI 모의면접','ai-chat':'실시간 메신저',admin:'회원 계정 관리'};
let activeView='ai-career';
function navigate(view){
  if(!Object.hasOwn(VIEWS,view))return;
  if(view==='admin'&&CampusAuth.user()?.role!=='admin')return;
  activeView=view;
  document.querySelectorAll('.view').forEach(el=>el.classList.toggle('active',el.id==='view-'+view));
  document.querySelectorAll('[data-view]').forEach(el=>{
    const selected=el.dataset.view===view;
    el.classList.toggle('selected',selected);
    if(selected)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');
  });
  document.getElementById('crumb').textContent=VIEWS[view];
  document.getElementById('sidebar').classList.remove('open');
  if(view==='ai-chat')CampusAI.openMessenger().catch(()=>{});
  if(view==='ai-match')CampusAI.loadMemberInvites().catch(()=>{});
  if(view==='admin')CampusAuth.refreshUsers();
}
async function init(){
  await CampusAuth.ready();
  document.querySelectorAll('[data-view]').forEach(el=>el.addEventListener('click',()=>navigate(el.dataset.view)));
  const menu=document.getElementById('mobileMenu');
  menu.addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
  CampusAI.init();
  navigate('ai-career');
}
init().catch(err=>{
  const el=document.getElementById('authAlert');if(el)el.textContent='화면 초기화 실패: '+err.message;
});
