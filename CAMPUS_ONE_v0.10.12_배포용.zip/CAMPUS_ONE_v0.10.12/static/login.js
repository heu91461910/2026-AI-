"use strict";
const $=id=>document.getElementById(id);
async function submit(path,username,password){
 const r=await fetch(path,{method:'POST',credentials:'same-origin',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({username,password})});
 const data=await r.json();if(!r.ok)throw new Error(data.error||'요청 실패');
 location.replace('/');
}
// A bookmarked /login.html must not re-prompt already authenticated students.
fetch('/api/auth/me',{credentials:'same-origin',cache:'no-store'})
 .then(r=>{if(r.ok)location.replace('/');}).catch(()=>{});
$('loginForm').addEventListener('submit',async e=>{e.preventDefault();$('message').textContent='';try{await submit('/api/auth/login',$('username').value,$('password').value);}catch(err){$('message').textContent=err.message;}});
$('registerForm').addEventListener('submit',async e=>{e.preventDefault();$('message').textContent='';if($('newPassword').value!==$('confirmPassword').value){$('message').textContent='비밀번호 확인이 일치하지 않습니다.';return;}try{await submit('/api/auth/register',$('newUsername').value,$('newPassword').value);}catch(err){$('message').textContent=err.message;}});
$('registerToggle').addEventListener('click',()=>{$('loginForm').hidden=true;$('registerForm').hidden=false;$('registerToggle').hidden=true;$('loginToggle').hidden=false;});
$('loginToggle').addEventListener('click',()=>{$('loginForm').hidden=false;$('registerForm').hidden=true;$('registerToggle').hidden=false;$('loginToggle').hidden=true;});
