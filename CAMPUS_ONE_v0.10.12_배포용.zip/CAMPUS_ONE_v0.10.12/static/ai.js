/* CAMPUS ONE AI v0.10.12 – user-owned board, Gemini embedding, interactive interview.
   Never use innerHTML for model or user content. Never persist resumes in localStorage. */
'use strict';
const CampusAI = (() => {
  let initialized = false;
  let listings = [];
  let interview = null;
  let interviewBusy = false;
  let interviewEpoch = 0;
  let interviewFinished = false;
  const $ = id => document.getElementById(id);
  const read = id => ($(id)?.value || '').trim();
  const checked = id => !!$(id)?.checked;

  async function api(url, method='GET', body) {
    const options = {method, credentials:'same-origin',headers:{}};
    if (method !== 'GET') {
      options.headers = {'Content-Type':'application/json','X-CSRF-Token':CampusAuth.csrf()};
      options.body = JSON.stringify(body || {});
    }
    const response = await fetch(url, options);
    let data;
    try { data = await response.json(); } catch (_) { throw Error('서버 응답을 읽지 못했습니다.'); }
    if (!response.ok) {const err=new Error(data.error || `서버 오류 HTTP ${response.status}`);err.httpStatus=response.status;throw err;}
    return data;
  }

  function node(tag, text='', className='') {
    const el = document.createElement(tag);
    if (className) el.className=className;
    el.textContent=String(text || '');
    return el;
  }
  function appendInline(parent, text) {
    // Only allow **bold**, inserting everything else as text nodes.
    for (const piece of String(text).split(/(\*\*[^*\n]+\*\*)/g)) {
      if (!piece) continue;
      if (/^\*\*[^*\n]+\*\*$/.test(piece)) parent.appendChild(node('strong',piece.slice(2,-2)));
      else parent.appendChild(document.createTextNode(piece));
    }
  }
  function renderAnswer(target,answer) {
    target.replaceChildren(); target.classList.add('ai-formatted');
    let list = null;
    for (const original of String(answer || '').split(/\r?\n/)) {
      const line=original.trim();
      if (!line) { list=null; continue; }
      const heading=line.match(/^(#{1,3})\s+(.+)$/);
      if (heading) {
        const h=document.createElement(heading[1].length>2?'h4':'h3');
        appendInline(h,heading[2]);target.appendChild(h);list=null;continue;
      }
      const bullet=line.match(/^(?:[-*•]|\d+[.)])\s+(.+)$/);
      if (bullet) {
        if (!list) { list=document.createElement('ul');target.appendChild(list); }
        const li=document.createElement('li');appendInline(li,bullet[1]);list.appendChild(li);continue;
      }
      list=null;const p=document.createElement('p');appendInline(p,line);target.appendChild(p);
    }
  }
  function reportError(target,err,previous) {
    const warning=node('p','분석 실패: '+(err?.message || '서버 연결을 확인하세요.')+(previous?' 이전 성공 결과는 유지했습니다.':''),'ai-error-banner');
    if (previous) {target.replaceChildren(warning,...previous);target.classList.add('ai-formatted');}
    else {target.replaceChildren(warning);target.classList.remove('ai-formatted');}
  }
  async function run(task) {
    if(task!=='career')return;
    const button=$('aiCareerRun'),result=$('aiCareerResult');
    const detail=read('aiCareerDetail')||'deep';
    const profile={major:read('aiMajor'),year:read('aiYear'),goal:read('aiGoal'),
      interests:read('aiInterest'),skills:read('aiSkills'),
      weekly_study_time:read('aiWeeklyHours'),constraints:read('aiConstraints')};
    if(!profile.major&&!profile.goal){result.textContent='학과 또는 희망 직무를 입력하세요.';return;}
    const previous=result.dataset.aiSuccess==='true'?Array.from(result.childNodes).map(el=>el.cloneNode(true)):null;
    button.disabled=true;result.textContent='Gemini가 로드맵을 분석 중입니다…';
    try{
      if(checked('aiCareerListings')){try{await loadListings(false);}catch(_){/* optional */}}
      const candidates=checked('aiCareerListings')?listings.slice(0,12).map(x=>({title:x.title,description:x.description,role:x.role,schedule:x.schedule,kind:x.kind})):[];
      const courses=[];
      const data=await api('/api/ai/analyze','POST',{task:'career',detail,profile,courses,candidates});
      renderAnswer(result,data.answer);result.dataset.aiSuccess='true';
    }catch(err){reportError(result,err,previous);}finally{button.disabled=false;}
  }

  const labels={club:'동아리',society:'학회',team:'프로젝트 팀',contest:'공모전 팀',member:'팀원 프로필'};
  async function loadListings(showStatus=true) {
    const result=await api('/api/ai/listings');
    listings=Array.isArray(result.items)?result.items:[];
    drawListings();
    if (showStatus) $('aiListStatus').textContent=`현재 등록된 모집글 ${listings.length}개 · 사용자 등록 정보 (공식 모집 여부 별도 확인)`;
    return listings;
  }
  function drawListings() {
    const area=$('aiListingRows');area.replaceChildren();
    if (!listings.length) {area.appendChild(node('p','아직 등록된 모집글이 없습니다. 첫 모집글을 등록해 보세요.','ai-note'));return;}
    for (const item of listings) {
      const card=node('article','','ai-listing-card');
      card.appendChild(node('small',labels[item.kind]||'모집글','ai-listing-kind'));
      card.appendChild(node('h3',item.title));
      card.appendChild(node('p',item.description));
      if (item.role) card.appendChild(node('p','모집 역할: '+item.role,'ai-listing-meta'));
      if (item.schedule) card.appendChild(node('p','활동 시간: '+item.schedule,'ai-listing-meta'));
      const controls=node('div','','ai-actions');
      if (item.apply_url && /^https:\/\//i.test(item.apply_url)) {
        const link=node('a','지원 링크 (직접 확인)');
        link.href=item.apply_url; link.target='_blank';link.rel='noopener noreferrer';
        controls.appendChild(link);
      }
      if (item.can_delete) {
        const remove=node('button','모집글 삭제','outline-button');
        remove.type='button'; remove.addEventListener('click',()=>deleteListing(item.id,remove));controls.appendChild(remove);
      }
      card.appendChild(controls);area.appendChild(card);
    }
  }
  async function addListing() {
    const button=$('aiListAdd'),status=$('aiListStatus');button.disabled=true;
    try {
      const data={kind:read('aiListKind'),title:read('aiListTitle'),description:read('aiListDescription'),
        role:read('aiListRole'),schedule:read('aiListSchedule'),apply_url:read('aiListUrl')};
      await api('/api/ai/listings/create','POST',data);
      ['aiListTitle','aiListDescription','aiListRole','aiListSchedule','aiListUrl'].forEach(id=>$(id).value='');
      await loadListings(false);status.textContent='모집글이 등록되었습니다. 다른 로그인 사용자에게도 공개됩니다.';
    } catch(err) {status.textContent='모집글 등록 실패: '+err.message;}
    finally {button.disabled=false;}
  }
  async function deleteListing(id,button) {
    if (!confirm('이 모집글을 삭제하시겠습니까?')) return;
    button.disabled=true;
    try {await api('/api/ai/listings/delete','POST',{id});await loadListings();}
    catch(err) {$('aiListStatus').textContent='모집글 삭제 실패: '+err.message;button.disabled=false;}
  }

  function interviewProfile() {
    return {job:read('aiInterviewJob'),mode:read('aiInterviewMode'),persona:read('aiInterviewPersona'),resume:read('aiInterviewResume')};
  }
  function interviewButtons() {
    const step=interview ? interview.history.length : 0;
    const canAnswer=!!interview && !interviewFinished && step < 6 && !!interview.question;
    const submit=$('aiInterviewAnswerSubmit');
    $('aiInterviewStart').disabled=interviewBusy || !!interview;
    $('aiInterviewFinish').disabled=interviewBusy || !interview || !step;
    submit.disabled=interviewBusy || !canAnswer;
    submit.textContent=interviewBusy ? 'AI가 답변을 분석하는 중…' :
      (step>=5 ? '6번 답변 제출 · 최종 평가 준비' : `${step+1}번 답변 제출 · ${step+2}번 꼬리질문 받기`);
    $('aiInterviewAnswerWrap').hidden=!canAnswer;
    submit.hidden=!canAnswer;
    submit.setAttribute('aria-busy',interviewBusy?'true':'false');
  }
  function clearInterview() {
    interviewEpoch++;
    interview=null;interviewBusy=false;interviewFinished=false;
    $('aiInterviewTranscript').replaceChildren();
    $('aiInterviewFinal').replaceChildren();
    $('aiInterviewAnswer').value='';
    $('aiInterviewStatus').textContent='새 면접을 시작할 수 있습니다. 이전 질문·답변은 브라우저 화면에서 지웠습니다.';
    interviewButtons();
  }
  function transcript(role,title,body) {
    const card=node('article','','ai-turn ai-turn-'+role);
    card.appendChild(node('strong',title));card.appendChild(node('p',body));
    $('aiInterviewTranscript').appendChild(card);
  }
  function errorText(err) {
    if (err?.httpStatus===429) return `Gemini 사용량 제한(HTTP 429): ${err.message} 답변은 그대로 남아 있습니다.`;
    if ([502,503,504].includes(err?.httpStatus)) return `Gemini 응답 오류(HTTP ${err.httpStatus}): ${err.message} 답변은 그대로 남아 있으니 재시도할 수 있습니다.`;
    return (err?.message || '서버 응답을 확인할 수 없습니다.')+' 답변을 유지했으니 다시 시도할 수 있습니다.';
  }
  async function interviewStart() {
    if (interview || interviewBusy) return;
    if (!checked('aiInterviewConsent')) {$('aiInterviewStatus').textContent='Gemini API 데이터 전송에 동의해 주세요.';return;}
    const profile=interviewProfile();
    if (!profile.job || profile.resume.length<30) {$('aiInterviewStatus').textContent='희망 직무와 30자 이상의 자기소개서·경험을 입력하세요.';return;}
    const epoch=++interviewEpoch;
    interviewBusy=true;interviewButtons();$('aiInterviewStatus').textContent='첫 면접 질문을 생성하는 중입니다…';
    try {
      const data=await api('/api/ai/interview','POST',{action:'start',profile,history:[]});
      if (epoch!==interviewEpoch) return; // Reset during a pending API call.
      if (!data || typeof data.question!=='string' || !data.question.trim()) throw Error('질문이 비어 있습니다. 다시 시작해 주세요.');
      interview={profile,history:[],question:data.question.trim()};interviewFinished=false;
      $('aiInterviewTranscript').replaceChildren();$('aiInterviewFinal').replaceChildren();
      transcript('question','면접관 · 1번 질문',data.question);
      if (data.focus) transcript('focus','질문 의도',data.focus);
      $('aiInterviewStatus').textContent='1번 질문에 답변을 입력한 뒤 아래 버튼을 눌러주세요. 최대 6문항까지 진행합니다.';
      $('aiInterviewAnswer').focus();
    } catch(err) {if (epoch===interviewEpoch) $('aiInterviewStatus').textContent='면접 시작 실패: '+errorText(err);}
    finally {if (epoch===interviewEpoch) {interviewBusy=false;interviewButtons();}}
  }
  async function interviewAnswer() {
    if (!interview || interviewBusy || interviewFinished || interview.history.length>=6) return;
    const answer=read('aiInterviewAnswer');
    if (answer.length<5) {$('aiInterviewStatus').textContent='답변을 5자 이상 입력해 주세요. 입력한 답변은 유지됩니다.';return;}
    const epoch=interviewEpoch, session=interview;
    const step=session.history.length;
    interviewBusy=true;interviewButtons();
    $('aiInterviewStatus').textContent=`${step+1}번 답변을 Gemini에 전송했습니다. 피드백과 다음 질문을 생성 중입니다…`;
    try {
      const data=await api('/api/ai/interview','POST',{
        action:'answer',profile:session.profile,
        history:session.history.map(({question,answer})=>({question,answer})),
        question:session.question,answer
      });
      if (epoch!==interviewEpoch || session!==interview) return;
      // Validate BEFORE updating history, so a malformed AI response can be retried.
      if (!data || typeof data.feedback!=='string' || !data.feedback.trim() ||
          typeof data.next_question!=='string' || !data.next_question.trim()) {
        throw Error('Gemini가 피드백 또는 다음 질문을 비워서 보냈습니다. 다시 요청해 주세요.');
      }
      session.history.push({question:session.question,answer});
      transcript('answer',`학생 · ${session.history.length}번 답변`,answer);
      transcript('feedback',`AI 피드백 · ${session.history.length}번`,
        data.feedback+'\n좋은 점: '+(data.strength||'미제공')+'\n보완할 점: '+(data.improve||'미제공'));
      $('aiInterviewAnswer').value='';
      session.question=data.next_question.trim();
      if (session.history.length<6) {
        transcript('question',`면접관 · ${session.history.length+1}번 꼬리질문`,session.question);
        $('aiInterviewStatus').textContent=`${session.history.length}/6 문항 답변 완료. ${session.history.length+1}번 질문에 답변하고 아래 버튼을 눌러주세요.`;
        $('aiInterviewAnswer').focus();
      } else {
        $('aiInterviewStatus').textContent='6문항을 마쳤습니다. 최종 평가 생성을 눌러주세요.';
      }
    } catch(err) {
      if (epoch===interviewEpoch && session===interview) {
        $('aiInterviewStatus').textContent=`${step+1}번 답변 처리 실패: `+errorText(err);
      }
    } finally {
      if (epoch===interviewEpoch && session===interview) {interviewBusy=false;interviewButtons();}
    }
  }
  async function interviewFinish() {
    if (!interview || !interview.history.length || interviewBusy) return;
    const epoch=interviewEpoch,session=interview;
    interviewBusy=true;interviewButtons();$('aiInterviewStatus').textContent='면접 종합 피드백을 작성 중입니다…';
    try {
      const data=await api('/api/ai/interview','POST',{action:'finish',profile:session.profile,history:session.history});
      if (epoch!==interviewEpoch || session!==interview) return;
      if (!data || !data.summary) throw Error('종합 평가가 비어 있습니다. 다시 요청해 주세요.');
      const sections=[['종합 평가',data.summary],['강점',data.strengths],['보완할 점',data.improvements],['다음 연습 과제',data.practice]];
      const target=$('aiInterviewFinal');target.replaceChildren();
      sections.forEach(([heading,body])=>{target.appendChild(node('h3',heading));target.appendChild(node('p',body||'내용 없음'));});
      interviewFinished=true;
      $('aiInterviewStatus').textContent=`${session.history.length}문항의 최종 평가를 생성했습니다. 새 면접을 시작하려면 '새 면접'을 누르세요.`;
    } catch(err) {if (epoch===interviewEpoch) $('aiInterviewStatus').textContent='최종 평가 실패: '+errorText(err);}
    finally {if (epoch===interviewEpoch && session===interview) {interviewBusy=false;interviewButtons();}}
  }

  // --- v0.10.5 real volunteer matching (opt-in profiles + hard availability + Gemini) ---
  const MEMBER_DAYS=['월','화','수','목','금','토','일'];
  const MEMBER_PERIODS=['오전','오후','저녁'];
  const traitsFromText=id=>read(id)?[read(id)]:[];
  function makeSlotGrid(id){
    const wrap=$(id);wrap.replaceChildren();
    for(const day of MEMBER_DAYS){
      const group=node('div','','member-slot-day');group.appendChild(node('strong',day+'요일'));
      for(const period of MEMBER_PERIODS){
        const label=node('label','','member-slot-choice');
        const input=document.createElement('input');input.type='checkbox';input.value=day+period;
        const span=node('span',period);
        label.append(input,span);group.appendChild(label);
      }
      wrap.appendChild(group);
    }
  }
  function memberSlots(id){return [...$(id).querySelectorAll('input:checked')].map(x=>x.value);}
  function setMemberSlots(id,slots){
    const selected=new Set(Array.isArray(slots)?slots:[]);
    $(id).querySelectorAll('input[type=checkbox]').forEach(x=>{x.checked=selected.has(x.value);});
  }
  function safeComma(array){return Array.isArray(array)?array.join(', '):'';}
  async function loadMemberProfile(){
    const result=await api('/api/ai/members/me');
    const p=result.profile;
    if(!p){$('memberProfileStatus').textContent='아직 내 카드가 없습니다. 간단한 내용을 입력하고 팀원 찾기를 시작하세요.';return;}
    $('memberAlias').value=p.alias||'';
    $('memberAbout').value=p.about||'';
    $('memberRole').value=p.role||'';
    $('memberSkills').value=p.skills||'';
    const style=(p.traits||[])[0]||'협력형';
    $('memberTraits').value=['협력형','계획형','주도형','자율형','탐구형'].includes(style)?style:'협력형';
    setMemberSlots('memberMySlots',p.slots);
    $('memberPublishConsent').checked=!!p.published;
    $('memberProfileStatus').textContent=p.published?'공개 참여 중 · 다른 로그인 학생의 매칭 후보에 표시됩니다.':'현재 비공개 상태입니다. 다시 공개 등록할 수 있습니다.';
  }
  function memberFormError(){
    if(!read('memberAlias'))return {id:'memberAlias',message:'별명을 입력해 주세요.'};
    if(!read('memberRole'))return {id:'memberRole',message:'할 수 있는 역할을 입력해 주세요.'};
    if(!read('memberAbout'))return {id:'memberAbout',message:'함께 하고 싶은 활동을 입력해 주세요.'};
    if(!memberSlots('memberMySlots').length)return {id:'memberMySlots',message:'활동 가능 시간을 하나 이상 선택해 주세요. ‘평일 저녁’ 같은 빠른 선택을 이용할 수 있습니다.'};
    if(!checked('memberPublishConsent'))return {id:'memberPublishConsent',message:'내 카드 공개와 Gemini 분석에 관한 안내를 확인하고 동의해 주세요.'};
    return null;
  }
  async function saveMember(){
    const status=$('memberProfileStatus'),button=$('memberSave');
    const validation=memberFormError();
    if(validation){status.textContent=validation.message;$(validation.id)?.focus();return false;}
    const data={alias:read('memberAlias'),about:read('memberAbout'),role:read('memberRole'),
      skills:read('memberSkills'),traits:traitsFromText('memberTraits'),
      slots:memberSlots('memberMySlots'),published:true,consent_ai:true};
    button.disabled=true;status.textContent='내 카드를 저장하는 중입니다…';
    try{
      await api('/api/ai/members/profile','POST',data);
      status.textContent='내 카드가 저장됐습니다. 아래에서 팀원 추천을 확인하세요.';
      await matchMembers();
      $('memberResultAnchor')?.scrollIntoView({behavior:'smooth',block:'start'});
      return true;
    }catch(err){status.textContent='프로필 저장 또는 추천 실패: '+err.message;return false;}
    finally{button.disabled=false;}
  }
  async function unpublishMember(){
    if(!confirm('매칭 참여를 중단하시겠습니까? 프로필이 다른 사람의 추천 결과에서 숨겨집니다.'))return;
    try{
      await api('/api/ai/members/unpublish','POST',{});
      $('memberPublishConsent').checked=false;
      $('memberProfileStatus').textContent='매칭 참여를 중단했습니다. 저장된 프로필을 다시 공개할 수 있습니다.';
      $('memberMatchRows').replaceChildren();
      if(matchRetryTimer){clearInterval(matchRetryTimer);matchRetryTimer=null;}
      await loadMemberInvites();
    }catch(e){$('memberProfileStatus').textContent='매칭 참여 중단 실패: '+e.message;}
  }
  function memberText(card,label,value){
    if(value){card.appendChild(node('p',label+String(value),'member-card-detail'));}
  }
  let matchRetryTimer=null;
  async function matchMembers(){
    if(matchRetryTimer){clearInterval(matchRetryTimer);matchRetryTimer=null;}
    const button=$('memberSearch'),status=$('memberSearchStatus'),area=$('memberMatchRows');
    const slots=memberSlots('memberMySlots');
    if(!slots.length){status.textContent='먼저 활동 가능 시간대를 하나 이상 선택해 주세요.';return;}
    // Empty filters are supported: activity time and the registered interests are sufficient.
    const query={role:read('memberWantRole'),interests:read('memberAbout'),
      traits:traitsFromText('memberWantTraits'),slots,ai_consent:checked('memberSearchConsent')};
    button.disabled=true;status.textContent=query.ai_consent?'등록된 학생 중 AI로 팀원을 찾는 중입니다…':'공통 시간대가 있는 학생을 찾는 중입니다…';
    try{
      // Include request status so already-invited students do not produce confusing HTTP 409 errors.
      const result=await api('/api/ai/members/search','POST',query);
      // A temporary invite-list error must not discard a successful matching result.
      const invitations=await api('/api/ai/members/invites').catch(()=>({items:[]}));
      const invitationsByAlias=new Map();
      for(const invite of invitations.items||[]){
        if(invite.direction==='sent'&&!invitationsByAlias.has(invite.public_id))invitationsByAlias.set(invite.public_id,invite);
      }
      // Use server time for cooldowns (browser clock may be inaccurate).
      const serverOffsetMs=Number.isFinite(invitations.server_now)
        ? invitations.server_now*1000-Date.now() : 0;
      const retryUpdates=[];
      area.replaceChildren();
      status.textContent=`추천 결과 ${result.count}명 · ${result.method==='embedding'?'Gemini AI 분석':'시간대·성향 분석'} (같이 활동 가능한 학생만 표시)`;
      if(result.warning && result.method!=='no_candidates'){
        area.appendChild(node('p',result.warning,'member-match-warning'));
      }
      if(!result.matches.length){
        const empty=node('div','','member-search-empty');
        empty.appendChild(node('strong','지금은 조건에 맞는 팀원이 없습니다.'));
        empty.appendChild(node('p','다른 학생이 참여 카드를 등록해야 추천할 수 있습니다. 가능 시간을 더 선택한 후 다시 시도해 보세요.'));
        area.appendChild(empty);return;
      }
      result.matches.forEach((person,index)=>{
        const card=node('article','','ai-listing-card member-result-card');
        const head=node('div','','member-card-head');
        head.appendChild(node('span',String(index+1).padStart(2,'0'),'member-rank-number'));
        const about=node('div','','member-card-heading');
        about.appendChild(node('h3',person.alias));
        about.appendChild(node('small',person.role||'역할 미입력','member-card-role'));
        head.appendChild(about);card.appendChild(head);
        const tags=node('div','','member-match-tags');
        tags.appendChild(node('span','시간 일치 '+(person.common_slots?.length||0)+'개','member-tag member-tag-primary'));
        if(person.common_traits?.length) tags.appendChild(node('span','성향 일치','member-tag'));
        if(typeof person.similarity==='number') tags.appendChild(node('span','AI 유사도 '+person.similarity.toFixed(2),'member-tag'));
        card.appendChild(tags);
        memberText(card,'공통 시간: ',safeComma(person.common_slots));
        const more=node('details','','member-card-more');
        more.appendChild(node('summary','소개·기술 더 보기'));
        memberText(more,'관심 분야: ',person.about);
        memberText(more,'보유 기술: ',person.skills);
        memberText(more,'성향: ',safeComma(person.traits));
        card.appendChild(more);
        const inviteDetails=node('details','','member-invite-custom');
        inviteDetails.appendChild(node('summary','신청 메시지 직접 쓰기 (선택)'));
        const note=document.createElement('textarea');note.rows=2;note.maxLength=300;
        note.placeholder='수정하지 않으면 기본 인사말로 신청됩니다.';
        note.setAttribute('aria-label',person.alias+'님에게 보낼 매칭 신청 메시지');
        inviteDetails.appendChild(note);card.appendChild(inviteDetails);
        const actions=node('div','','member-request-actions');
        const send=node('button','매칭 신청','primary-button');send.type='button';
        const feedback=node('p','','ai-note member-request-feedback');
        const previous=invitationsByAlias.get(person.public_id);
        if(previous?.status==='pending') {send.textContent='신청 완료 · 응답 대기';send.disabled=true;}
        if(previous?.status==='accepted') {send.textContent='대화방 열기';send.className='outline-button';}
        if(previous?.status==='declined'||previous?.status==='cancelled') {
          const cancelled=previous.status==='cancelled';
          const retryAt=Number(previous.retry_at)||0;
          const updateRetry=()=>{
            if(send.dataset.inviteState==='sending'||send.dataset.inviteState==='submitted')return false;
            const remaining=Math.ceil(retryAt-(Date.now()+serverOffsetMs)/1000);
            if(remaining<=0){
              send.textContent='다시 매칭 신청';send.disabled=false;
              feedback.textContent=cancelled?'취소 대기 시간이 끝났습니다. 다시 신청할 수 있습니다.':'거절 후 재신청 대기 시간이 끝났습니다.';
              return false;
            }
            const hours=Math.floor(remaining/3600);
            const minutes=Math.floor(remaining%3600/60);
            const seconds=remaining%60;
            const countdown=hours?`${hours}시간 ${String(minutes).padStart(2,'0')}분`:`${minutes}:${String(seconds).padStart(2,'0')}`;
            send.textContent=cancelled?'신청 취소됨':'상대방 거절 · 대기 중';send.disabled=true;
            feedback.textContent=`재신청까지 ${countdown} 남았습니다.`;
            return true;
          };
          if(retryAt && updateRetry())retryUpdates.push(updateRetry);
        }
        send.addEventListener('click',async()=>{
          if(previous?.status==='accepted'){
            try{await openInviteChat(previous.id);}catch(err){feedback.textContent='대화방을 열 수 없습니다: '+err.message;}
            return;
          }
          const intro=read('memberAbout').replace(/\s+/g,' ').slice(0,70);
          const message=note.value.trim() || ('안녕하세요! '+(intro||'함께 프로젝트에 참여하고 싶습니다.')+' 관련해서 함께 활동하고 싶어 팀 매칭을 제안합니다.').slice(0,300);
          send.dataset.inviteState='sending';
          send.disabled=true;send.textContent='신청 중…';feedback.textContent='';
          try{
            await api('/api/ai/members/invite','POST',{public_id:person.public_id,note:message});
            send.dataset.inviteState='submitted';
            send.textContent='신청 완료 · 응답 대기';
            feedback.textContent='신청이 전송됐습니다. 아래 신청함에서 상태와 취소 버튼을 확인하세요.';
            await loadMemberInvites();
          }catch(err){
            send.dataset.inviteState='error';
            if(err.httpStatus===409){send.textContent='재신청 제한';send.disabled=true;feedback.textContent=err.message+' 신청함을 확인해 주세요.';}
            else{send.disabled=false;send.textContent='매칭 신청';feedback.textContent='신청 실패: '+err.message;}
          }
        });
        actions.appendChild(send);card.append(actions,feedback);area.appendChild(card);
      });
      if(retryUpdates.length){
        matchRetryTimer=setInterval(()=>{
          if(!area.isConnected||!retryUpdates.filter(update=>update()).length){
            clearInterval(matchRetryTimer);matchRetryTimer=null;
          }
        },1000);
      }
    }catch(err){status.textContent='팀원 추천 실패: '+err.message;}
    finally{button.disabled=false;}
  }
  let latestPendingReceived=0;
  let inviteLoadEpoch=0;
  async function loadMemberInvites(){
    const epoch=++inviteLoadEpoch;
    const area=$('memberInvitesRows');
    const result=await api('/api/ai/members/invites');
    if(epoch!==inviteLoadEpoch)return;
    const items=Array.isArray(result.items)?result.items:[];
    area.replaceChildren();
    latestPendingReceived=items.filter(x=>x.direction==='received'&&x.status==='pending').length;
    const counter=$('memberNavCount');
    if(counter){counter.hidden=!latestPendingReceived;counter.textContent=latestPendingReceived>99?'99+':String(latestPendingReceived);}
    const statuses={pending:'응답 대기',accepted:'수락 완료',declined:'거절됨',cancelled:'신청 취소됨'};
    for(const [direction,title,emptyLabel] of [
      ['received','받은 신청','아직 받은 매칭 신청이 없습니다.'],
      ['sent','보낸 신청','아직 보낸 매칭 신청이 없습니다.']]){
      const section=node('section','','member-invite-group');
      const header=node('div','','member-invite-heading');
      const group=items.filter(x=>x.direction===direction);
      header.appendChild(node('h3',title));
      const pending=group.filter(x=>x.status==='pending').length;
      header.appendChild(node('span',pending?'응답 대기 '+pending+'건':'총 '+group.length+'건','member-invite-count'));
      section.appendChild(header);
      if(!group.length)section.appendChild(node('p',emptyLabel,'member-invite-empty'));
      for(const item of group){
        const card=node('article','','ai-listing-card member-invite-item');
        const headline=node('div','','member-invite-item-head');
        headline.appendChild(node('h4',item.alias));
        headline.appendChild(node('span',statuses[item.status]||'상태 확인','member-invite-state'+(item.status==='pending'?' is-pending':'')));
        card.appendChild(headline);
        card.appendChild(node('p',item.note,'member-invite-note'));
        const actions=node('div','','ai-actions');
        if(direction==='received'&&item.status==='pending'){
          for(const [accept,label] of [[true,'수락하고 대화'],[false,'거절']]){
            const button=node('button',label,accept?'primary-button':'outline-button');button.type='button';
            button.addEventListener('click',async()=>{
              button.disabled=true;
              try{
                await api('/api/ai/members/respond','POST',{id:item.id,accept});
                await loadMemberInvites();
                if(accept)await openInviteChat(item.id);
              }catch(err){button.disabled=false;alert('매칭 요청 처리 실패: '+err.message);}
            });actions.append(button);
          }
        }
        if(direction==='sent'&&item.status==='pending'){
          const cancel=node('button','신청 취소','outline-button member-cancel-button');cancel.type='button';
          cancel.addEventListener('click',async()=>{
            if(!confirm(item.alias+'님에게 보낸 매칭 신청을 취소하시겠습니까?'))return;
            cancel.disabled=true;cancel.textContent='취소 중…';
            try{
              await api('/api/ai/members/cancel','POST',{id:item.id});
              await loadMemberInvites();
              // Avoid showing a stale pending state on the recommendation card.
              const matchRows=$('memberMatchRows');if(matchRows)matchRows.replaceChildren();
              if(matchRetryTimer){clearInterval(matchRetryTimer);matchRetryTimer=null;}
              $('memberSearchStatus').textContent='신청이 취소됐습니다. 추천을 다시 받으면 최신 신청 상태가 표시됩니다.';
            }catch(err){cancel.disabled=false;cancel.textContent='신청 취소';alert('신청 취소 실패: '+err.message);}
          });actions.append(cancel);
        }
        if(item.status==='accepted'){
          const open=node('button','대화방 열기','outline-button');open.type='button';
          open.addEventListener('click',()=>openInviteChat(item.id).catch(e=>alert('대화방 열기 실패: '+e.message)));
          actions.append(open);
        }
        if(actions.childElementCount)card.append(actions);
        section.append(card);
      }
      area.append(section);
    }
  }

  let selectedChatRoom=null;
  let chatLoadBusy=false;
  let chatLoadAgain=false;
  let chatRoomsCached=[];
  const chatDate=(seconds)=>new Date(seconds*1000).toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'});
  function goMessenger(){const button=document.querySelector('[data-view="ai-chat"]');if(button)button.click();}
  async function openInviteChat(inviteId){
    const {room_id}=await api('/api/chat/room-for-invite?invite_id='+encodeURIComponent(inviteId));
    goMessenger();await loadChatRooms();await openChatRoom(room_id);
  }
  async function loadChatRooms(){
    const data=await api('/api/chat/rooms');
    chatRoomsCached=data.rooms||[];
    const unread=chatRoomsCached.reduce((n,r)=>n+r.unread,0);
    const nav=$('chatNavCount');nav.hidden=unread===0;nav.textContent=unread>99?'99+':String(unread);
    const wrap=$('chatRooms');wrap.replaceChildren();
    if(!chatRoomsCached.length){const empty=node('div','','chat-room-empty'); empty.appendChild(node('strong','아직 열린 대화방이 없습니다.')); empty.appendChild(node('p','AI 팀 매칭 제안을 수락하면 이곳에 대화방이 자동으로 생성됩니다.')); wrap.appendChild(empty); return;}
    for(const r of chatRoomsCached){
      const btn=node('button','','chat-room-row'+(selectedChatRoom===r.id?' active':''));btn.type='button';
      const avatar=node('span',Array.from(r.alias||'상대방')[0]||'C','chat-peer-avatar');
      const info=node('div','','chat-room-content');
      const head=node('div','','chat-room-top');
      head.appendChild(node('strong',r.alias));
      head.appendChild(node('time',chatDate(r.last_at),'chat-room-date'));
      info.appendChild(head);
      info.appendChild(node('small',r.last_body||'대화를 시작해 보세요.'));
      btn.append(avatar,info);
      if(r.unread)btn.appendChild(node('span',r.unread>99?'99+':String(r.unread),'chat-unread'));
      btn.addEventListener('click',()=>openChatRoom(r.id).catch(e=>{$('chatStatus').textContent='대화방 오류: '+e.message;}));
      wrap.appendChild(btn);
    }
  }
  async function openChatRoom(roomId){
    selectedChatRoom=roomId;
    const room=chatRoomsCached.find(r=>r.id===roomId);
    $('chatTitle').textContent=room?room.alias:'대화방';
    $('chatInfo').textContent='수락된 매칭 참여자만 대화할 수 있으며 새 메시지는 자동으로 표시됩니다.';
    $('chatInput').disabled=false;$('chatSend').disabled=false;
    await loadChatMessages();await loadChatRooms();
  }
  async function loadChatMessages(){
    if(selectedChatRoom===null)return;
    if(chatLoadBusy){chatLoadAgain=true;return;}
    const roomId=selectedChatRoom;chatLoadBusy=true;
    try{
      const data=await api('/api/chat/messages?room_id='+encodeURIComponent(roomId));
      if(selectedChatRoom!==roomId)return;
      const wrap=$('chatMessages'),lastId=wrap.dataset.lastId||'';
      const items=data.items||[];const newLast=String(items.at(-1)?.id||'');
      const readMarker=items.filter(m=>m.mine&&m.read).map(m=>m.id).join(',');
      const roomChanged=wrap.dataset.roomId!==String(roomId);
      // Read receipts can change even when there are no new messages.
      if(lastId!==newLast||roomChanged||wrap.dataset.readMarker!==readMarker){
        const atBottom=wrap.scrollHeight-wrap.scrollTop-wrap.clientHeight<90;
        wrap.replaceChildren();
        if(!items.length)wrap.appendChild(node('p','첫 메시지를 보내 대화를 시작하세요.','ai-note'));
        for(const m of items){
          const bubble=node('article','','chat-bubble '+(m.mine?'mine':'theirs'));
          bubble.appendChild(node('p',m.body));
          const meta=node('div','','chat-bubble-meta');
          meta.appendChild(node('time',chatDate(m.created_at),'chat-message-time'));
          if(m.mine){
            const receipt=node('span',m.read?'✓ 읽음':'✓ 전송됨','chat-read-state'+(m.read?' is-read':''));
            receipt.setAttribute('aria-label',m.read?'상대방이 읽었습니다':'상대방이 아직 읽지 않았습니다');
            meta.appendChild(receipt);
          }
          bubble.appendChild(meta);
          wrap.appendChild(bubble);
        }
        wrap.dataset.lastId=newLast;wrap.dataset.roomId=String(roomId);wrap.dataset.readMarker=readMarker;
        if(atBottom||!lastId||roomChanged)wrap.scrollTop=wrap.scrollHeight;
      }
      // Only acknowledge as read while the actual chat view and browser tab are visible.
      if(items.length && !document.hidden && $('view-ai-chat').classList.contains('active')){
        await api('/api/chat/read','POST',{room_id:roomId,last_id:items.at(-1).id});
      }
    }finally{
      chatLoadBusy=false;
      if(chatLoadAgain){chatLoadAgain=false;loadChatMessages().catch(e=>{$('chatStatus').textContent='대화 갱신 실패: '+e.message;});}
    }
  }
  async function sendChatMessage(event){
    event.preventDefault();if(selectedChatRoom===null)return;
    const input=$('chatInput'),body=input.value.trim();if(!body)return;
    const button=$('chatSend');button.disabled=true;$('chatStatus').textContent='전송 중…';
    try{await api('/api/chat/send','POST',{room_id:selectedChatRoom,body});input.value='';
      $('chatStatus').textContent='';await loadChatMessages();await loadChatRooms();input.focus();}
    catch(err){$('chatStatus').textContent='전송 실패: '+err.message;}
    finally{button.disabled=false;}
  }
  function presetSlots(kind){
    const keys=[];
    for(const day of MEMBER_DAYS){for(const period of MEMBER_PERIODS){
      if((kind==='weekday_evening'&&'월화수목금'.includes(day)&&period==='저녁')||
         (kind==='weekend'&&'토일'.includes(day))||
         (kind==='afternoon'&&'월화수목금'.includes(day)&&period==='오후'))keys.push(day+period);
    }}
    setMemberSlots('memberMySlots',keys);
    $('memberProfileStatus').textContent='시간대 선택됨: '+(kind==='clear'?'없음':keys.length+'개');
  }
  let eventStream=null;
  let liveRefreshTimer=null;
  function liveRefresh(){
    if(liveRefreshTimer)return;
    liveRefreshTimer=setTimeout(()=>{
      liveRefreshTimer=null;
      loadChatRooms().then(()=>{
        if(document.getElementById('view-ai-chat').classList.contains('active'))return loadChatMessages();
      }).catch(()=>{});
      loadMemberInvites().catch(err=>{$('memberInvitesRows').textContent='신청 목록을 불러오지 못했습니다: '+err.message;});
    },100);
  }
  function startLiveEvents(){
    if(eventStream||!window.EventSource)return;
    eventStream=new EventSource('/api/chat/events');
    const indicator=$('liveStatus');
    eventStream.addEventListener('update',liveRefresh);
    eventStream.addEventListener('ready',liveRefresh);
    eventStream.onopen=()=>{if(indicator){indicator.textContent='실시간 연결됨';indicator.className='live-pill live-online';}liveRefresh();};
    eventStream.onerror=()=>{if(indicator){indicator.textContent='실시간 재연결 중';indicator.className='live-pill live-offline';}};
  }
  function chatHeartbeat(){
    if(!initialized||document.hidden)return;
    if(document.getElementById('view-ai-chat').classList.contains('active')){
      loadChatRooms().then(()=>loadChatMessages()).catch(e=>{$('chatStatus').textContent='연결 확인 필요: '+e.message;});
    }else{loadChatRooms().catch(()=>{});}
    // If the SSE connection drops, this bounded 30s fallback still refreshes invites.
    loadMemberInvites().catch(()=>{});
  }

  function init() {
    if (initialized) return;
    initialized=true;
    $('aiCareerRun').addEventListener('click',()=>run('career'));
    $('aiListAdd').addEventListener('click',addListing);
    $('aiListRefresh').addEventListener('click',()=>loadListings().catch(e=>{$('aiListStatus').textContent='모집글 조회 실패: '+e.message;}));
    $('aiInterviewStart').addEventListener('click',interviewStart);
    $('aiInterviewAnswerSubmit').addEventListener('click',interviewAnswer);
    $('aiInterviewFinish').addEventListener('click',interviewFinish);
    $('aiInterviewReset').addEventListener('click',clearInterview);
    makeSlotGrid('memberMySlots');
    $('memberSave').addEventListener('click',saveMember);
    $('memberUnpublish').addEventListener('click',unpublishMember);
    $('memberSearch').addEventListener('click',matchMembers);
    document.querySelectorAll('[data-member-preset]').forEach(b=>b.addEventListener('click',()=>presetSlots(b.dataset.memberPreset)));
    $('memberGoChat').addEventListener('click',goMessenger);
    $('chatRefresh').addEventListener('click',()=>loadChatRooms().catch(e=>{$('chatStatus').textContent=e.message;}));
    $('chatForm').addEventListener('submit',sendChatMessage);
    document.addEventListener('visibilitychange',()=>{
      if(!document.hidden && $('view-ai-chat').classList.contains('active')){
        loadChatMessages().catch(e=>{$('chatStatus').textContent='읽음 상태 확인 실패: '+e.message;});
      }
    });
    $('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();$('chatForm').requestSubmit();}});
    startLiveEvents();
    setInterval(chatHeartbeat,30000);
    loadChatRooms().catch(()=>{});
    $('memberRefreshInvites').addEventListener('click',()=>loadMemberInvites().catch(err=>{$('memberInvitesRows').textContent='제안함 조회 실패: '+err.message;}));
    loadMemberProfile().catch(err=>{$('memberProfileStatus').textContent='프로필 조회 실패: '+err.message;});
    loadMemberInvites().catch(err=>{$('memberInvitesRows').textContent='신청 목록 조회 실패: '+err.message;});
    interviewButtons();
    loadListings().catch(e=>{$('aiListStatus').textContent='모집글 조회 실패: '+e.message;});
  }
  async function openMessenger(){
    await loadChatRooms();
    if(selectedChatRoom!==null) await loadChatMessages();
  }
  return {init,loadChatRooms,loadMemberInvites,openMessenger};
})();
